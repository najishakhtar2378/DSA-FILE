public class CountNegetive {
  public static  int countNegatives(int[][] nums) {
    int countNeg = 0;
    int row = nums.length;
    int col = nums[0].length;
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++) {
        if (nums[i][j] < 0) {
          countNeg++;
        }
      }
    }
    return countNeg;
  }
  public static void main(String[] args) {
    int nums[][]={{4,3,2,-1},
              {3,2,1,-1},
              {1,1,-1,-2},
              {-1,-1,-2,-3}};
              System.out.println(countNegatives(nums));
  }
  
}
