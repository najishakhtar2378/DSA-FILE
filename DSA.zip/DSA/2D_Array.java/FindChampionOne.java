public class FindChampionOne {
  public static int ChampionOne(int grid[][]){
    int m=grid.length;
    int n=grid[0].length;
    int count=0;
    for(int i=0;i<m;i++){
      for(int j=0;j<n;j++){
        if(grid[i][j]==1){
          count++;
        }
        if (count==m-1){
          return i;
      }
      }
    }
    return -1;
  }
  public static void main(String[] args) {
    int grid[][]={{0,1},{0,0}};
    System.out.println(ChampionOne(grid));
  }
}
