import java.util.Arrays;
public class FindPeekElement2 {
  public static int[] findPeek2(int peek[][]){
    int m=peek.length;
    int n=peek[0].length;
    int row=-1;
    int col=-1;
    int res=Integer.MIN_VALUE;
    for(int i=0;i<m;i++){
      for(int j=0;j<n;j++){
        if(res<peek[i][j]){
          res=peek[i][j];
          row=i;
          col=j;
        }
      }
    }
    return new int[]{row,col};
  }
  public static void main(String[] args) {
    int peek[][]={{1,4},{3,2}};
    int ans[]=findPeek2(peek);
    System.out.println(Arrays.toString(ans));
  }
}
