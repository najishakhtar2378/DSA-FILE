public class FlippingImage {
  public static void reverse(int arr[]) {
    int i = 0;
    int j = arr.length - 1;
    while (i < j) {
      int temp = arr[i];
      arr[i] = arr[j];
      arr[j] = temp;
      i++;
      j--;
    }
  }

  public static int[][] flipAndInvertImage(int[][] image) {
    int n = image.length;
    for (int i = 0; i < n; i++) {
      reverse(image[i]);
      for (int j = 0; j < n; j++) {
        if (image[i][j] == 1) {
          image[i][j] = 0;
        } else {
          image[i][j] = 1;
        }

      }
    }
    return image;
  }
  public static void main(String[] args) {
    FlippingImage fp=new FlippingImage();
    int image[][]={{1,1,0},{1,0,1},{0,0,0}};
    System.out.println(fp.flipAndInvertImage(image));
    
    
  }
}
