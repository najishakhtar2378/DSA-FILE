import java.util.ArrayList;
import java.util.Collections;
public class KthSmallestElemtSortedMat {
   public static int kthSmallest(int[][] matrix, int k) {
        ArrayList<Integer>ls=new ArrayList<>();
        int n=matrix.length;
        int m=matrix[0].length;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                  ls.add(matrix[i][j]);
              }

            }
            Collections.sort(ls);
              return ls.get(k-1);
        }
     public static void main(String[] args) {
       int matrix[][]=
        {{1,5,9},
        {10,11,13},
        {12,13,15}};
      System.out.println(kthSmallest(matrix, 8));
     }
}
