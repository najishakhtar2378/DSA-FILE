import java.util.ArrayList;

public class SetZerosMatrix {
      public static void setZeroes(int[][] matrix) {
        int m=matrix.length;
        int n=matrix[0].length;

        ArrayList<Integer> row=new ArrayList<>();
        ArrayList<Integer> col=new ArrayList<>();
      // 0 find
        for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                if(matrix[i][j]==0){
                row.add(i);
                col.add(j);
            }
         }
        }
        // row 0
        for(int i=0;i<row.size();i++){
            int idx=row.get(i);
            for(int j=0;j<n;j++){
                matrix[idx][j]=0;
            }
        }
        // col 0
        for(int i=0;i<col.size();i++){
            int idx=col.get(i);
            for(int j=0;j<m;j++){
                matrix[j][idx]=0;
            }
        }
        return;
    }
    public static void main(String[] args) {
      int matrix[][]= {{1,1,1},{1,0,1},{1,1,1}};
      setZeroes(matrix);
      for(int i=0;i<matrix.length;i++){
        for(int j=0;j<matrix[0].length;j++){
          System.out.print(matrix[i][j]+" ");
        }
        System.out.println();
      }
}
    }