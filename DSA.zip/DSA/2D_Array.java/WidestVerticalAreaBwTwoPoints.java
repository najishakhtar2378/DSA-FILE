import java.util.Arrays;

public class WidestVerticalAreaBwTwoPoints {
  public static int widestArea(int [][] points){
    int res[]=new int[points.length];
    //along x Axis sorting
    for(int i=0;i<points.length;i++){
      res[i]=points[i][0];
    }
    Arrays.sort(res);
    int maxGap=Integer.MIN_VALUE;
    for(int i=1;i<res.length;i++){
      maxGap=Math.max(maxGap,res[i]-res[i-1]);
    }
    return maxGap;
  }
  public static void main(String[] args) {
    int points[][]  ={{8,7},{9,9},{7,4},{9,7}};
    System.out.println(widestArea(points));
  }
  
}
