import java.util.Scanner;
public class practice_question {

    // problem 01
    public static void main(String[] args) {
        // int[][] array={{4,7,8},{8,8,7}};
        // int count=0;
        // for(int i=0;i<array.length;i++){
        //     for(int j=0;j<array[0].length;j++){
        //         if(array[i][j]==7){
        //             count++;
        //         }
        //     }
        // }
        // System.out.println("the total no 7 is:"+count);

        // problem 02
        
        // int[][]nums = {{1,4,9},{11,4,3},{2,2,3}};
        // int sum=0;
        // for(int j=0;j<nums[0].length;j++){
        //     sum+=nums[1][j];
        // }
        // System.out.println("sum is="+sum);

        // problem 03
        // Transpose of matrix
        Scanner sc=new Scanner(System.in);
        System.out.println("Enetr the row");
        int r=sc.nextInt();
        System.out.println("enter the colms");
        int c=sc.nextInt();
        int[][] matrix=new int[r][c];
        System.out.print("enter:" +(r*c)+" values :");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++)
                matrix[i][j]=sc.nextInt();
            }
            System.out.print("original matrix is :");
            for(int i=0;i<r;i++){
                for(int j=0;j<c;j++){
                    System.out.print(matrix[i][j]+" ");
                }
                System.out.println();
            }
            System.out.println("transpose matrix is:");
            for(int i=0;i<c;i++){
                for(int j=0;j<r;j++){
                    System.out.print(matrix[j][i]+" ");

                }
                System.out.println();
            }
        }


    }
