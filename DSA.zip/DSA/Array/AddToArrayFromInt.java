import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class AddToArrayFromInt {
    public static List<Integer> addToArrayForm(int[] nums, int k) {
        List<Integer>ls=new ArrayList<>();
        int n=nums.length;
        for(int i=n-1;i>=0;i--){
             k=k+nums[i];
             ls.add(k%10);
             k=k/10;
        }
        while(k>0){ //if carry left then
           ls.add(k%10);
           k=k/10;
        }

         Collections.reverse(ls);
                 return ls;
    }
    public static void main(String[] args) {
      int nums[]={2,7,4};
      int k=181;
      System.out.println(addToArrayForm(nums, k));
      
    }
  
}
