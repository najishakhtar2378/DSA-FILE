import java.util.Arrays;

public class ApplyOpnArray {
  public static  int[] applyOperations(int[] nums) {
    int res[] = new int[nums.length];
    int count = 0;
    int i;
    for (i = 0; i < nums.length - 1; i++) {
      if (nums[i] != 0) { //koi v nums 0 na ho tb
        if (nums[i]==nums[i+1]) {
          res[count]=nums[i]*2;
          i++; //jab num equal hoga tb uske index increase krenge
        } else {
          res[count]=nums[i]; // jb  i and i+1 same n ho tb
        }
        count++;
      }
    }
    if (i != nums.length) { // jb itteration end ho jaye
      res[count] = nums[nums.length - 1];
    }
   
    return res;
  }
  public static void main(String[] args) {
    ApplyOpnArray oa=new ApplyOpnArray();
    int nums[]={1,2,2,1,1,0};
    int res[]=oa.applyOperations(nums);
    System.out.println(Arrays.toString(res));
   
  }
}
