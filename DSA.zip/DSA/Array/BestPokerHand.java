public class BestPokerHand {
  public static String bestPokerHand(int ranks[], char suits[]) {
    int max = 0;
    int card = 0;
    char ch = suits[0];
    int res[] = new int[14];
    for (int i = 0; i < 5; i++) {
      res[ranks[i]]++;
      max = Math.max(max, res[ranks[i]]);
      if (suits[i] == ch) {
        card++;
      }
    }
    if (card == 5) {
      return "Flush";
    } else {
      return max >= 3 ? "Three of Kind" : (max == 2 ? "Pair" : "High Card");
    }
  }

  public static void main(String[] args) {
    int ranks[] = { 13, 2, 13, 1, 9 };
    char suits[] = { 'a', 'a', 'a', 'a', 'a' };
    System.out.println(bestPokerHand(ranks, suits));
  }
  
}
