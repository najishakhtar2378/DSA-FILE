public class BuyAndSell3 {
  public static int maxProfit(int[] prices) {
    int MinPrice1 = Integer.MAX_VALUE;
    int profit1 = 0;
    int MinPrice2 = Integer.MAX_VALUE;
    int profit2 = 0;
    for (int i = 0; i < prices.length; i++) {
      MinPrice1 = Math.min(prices[i], MinPrice1);
      profit1 = Math.max(profit1, prices[i] - MinPrice1);
      MinPrice2 = Math.min(MinPrice2, prices[i] - profit1);
      profit2 = Math.max(profit2, prices[i] - MinPrice2);
    }
    return profit2;

  }
  public static void main(String[] args) {
    int prices[]={3,3,5,0,0,3,1,4};
    System.out.println(maxProfit(prices));
  }
  
}
