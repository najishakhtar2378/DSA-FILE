import java.util.ArrayList;
import java.util.List;
public class Cobination {
    static List<List<Integer>> ans=new ArrayList<>();
    public static List<List<Integer>> combine(int n, int k) {
           List<Integer> combine =new ArrayList<>();
            solve(n,k,0,combine);
            return ans;
    }
    public static void solve(int n,int k,int idx,List<Integer> combine){
        if(k==0){
            ans.add(new ArrayList<>(combine));
             return;
        }
           for(int i=idx+1;i<=n;i++){ //idx+1 duplicate  no found
           combine.add(i);
            solve(n,k-1,i, combine);
            combine.remove(combine.size()-1);
        }
    }
    public static void main(String[] args) {
      int n=4;
      int k=2;
      System.out.println(combine(n, k));
      
    }
  
}
