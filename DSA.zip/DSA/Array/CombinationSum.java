import java.util.ArrayList;
import java.util.List;
public class CombinationSum {
        public  static void CombinationSum1(int arr[],int tar,int idx,List<List<Integer>>ans,List<Integer>combin){
          // base case
          if(idx==arr.length){
            if(tar==0){
              ans.add(new ArrayList<>(combin));
              System.out.println(ans);
            }
            return;
          }
          if(arr[idx]<=tar){
            combin.add(arr[idx]);
            //single include 
            CombinationSum1(arr,tar-arr[idx],idx+1,ans,combin);
            // multiple times include
            CombinationSum1(arr,tar-arr[idx],idx,ans,combin);
            // bactracking time 
            combin.remove(combin.size()-1);
          }
          //exclude
          CombinationSum1(arr,tar,idx+1,ans,combin);
        }
        public static  List<List<Integer>>CombinationSum(int arr[],int tar){
          List<List<Integer>>ans=new ArrayList<>();
          CombinationSum1(arr,tar,0,ans,new ArrayList<>());
          return ans;
        }
        public static void main(String[] args) {
          int arr[]={2,3,4,5};
          int tar=7;
          CombinationSum(arr, tar);
          
  }
}
