import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class CombinationSum2 {
      public static List<List<Integer>> combinationSum2(int[] arr, int target) {
        List<List<Integer>>ans=new ArrayList<>();
        ArrayList<Integer>combin=new ArrayList<>();
        Arrays.sort(arr);
        Combination(arr,target,0,combin,ans);
        return ans;
      }
    public static void Combination(int arr[],int target,int idx,ArrayList<Integer>combin,List<List<Integer>>ans){
           if(target==0){ 
                ans.add(new ArrayList<Integer>(combin));
                System.out.println(ans);
              return;
           }
                for(int i=idx;i<arr.length;i++){
                  //condition for   duplicate combination
                    if((i==idx||arr[i-1]!=arr[i])&&arr[i]<=target){
                 combin.add(arr[i]);
                 Combination(arr,target-arr[i],i+1,combin,ans);
                combin.remove(combin.size()-1);

                    }  
              
                }
    }
    public static void main(String[] args) {
      int arr[]={1,6,1,2,4};
      int target=7;
      combinationSum2(arr, target);
    }
}
