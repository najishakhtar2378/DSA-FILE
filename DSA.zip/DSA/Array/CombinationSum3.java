import java.util.ArrayList;
import java.util.List;
public class CombinationSum3 {
  public static List<List<Integer>>CombinationSum3(int k,int n){
    List<List<Integer>>ans=new ArrayList<>();
    ArrayList<Integer>combin=new ArrayList<>();
    Combination3(k,n,1,new ArrayList<>(),ans);
    return ans;
  }
  public static void Combination3(int k,int n,int idx,ArrayList<Integer>combin,List<List<Integer>>ans){
    //base case 
    if(combin.size()==k && n==0){
      ans.add(new ArrayList<>(combin));
      System.out.println(ans);
      return;
    }
    for(int i=idx;i<=9;i++){
      combin.add(i);
      //recursion call
      Combination3(k,n-i,i+1,combin,ans);
      //backtrakcing
      combin.remove(combin.size()-1);

    }
  }
  public static void main(String[] args) {
    int k=3;
    int n=7;
    CombinationSum3(k, n);
  }
}
