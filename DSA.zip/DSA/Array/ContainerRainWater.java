public class ContainerRainWater {
  public static int MaxArea(int height[]){
    int lp=0;
    int rp=height.length-1;
    int maxWater=0;
    while(lp<rp){
      int w=rp-lp;
      int ht=Math.min(height[rp],height[lp]);
      int currWater=w*ht;
      maxWater=Math.max(maxWater,currWater);

      if(height[lp]<height[rp]){
        lp++;
      }else{
        rp--;
      }
    }
    return maxWater;
  }
  public static void main(String[] args) {
    int height[]={1,8,6,2,5,4,8,3,7};
    System.out.println(MaxArea(height));
  }
  
}
