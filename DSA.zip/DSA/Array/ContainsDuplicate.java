import java.util.HashMap;

public class ContainsDuplicate {
  public static boolean ContainDup(int nums[],int k){
    HashMap<Integer,Integer>hm = new HashMap<>();
    // Integer store nums value and other Integer Store indeces of nums
    for(int i=0;i<nums.length;i++){
      if(!hm.containsKey(nums[i])){
        hm.put(nums[i],i); // nums[i] store nums and i store indeces 
      }else{
        int previndex=hm.get(nums[i]);
        if(Math.abs(previndex-i)<=k){
          return true;
        }else{
          hm.put(nums[i],i); // if abs indeces are not less than or eqal to k then store next nums and its indeces
        }
      }
    }
    return false;
  }
  public static void main(String[] args) {
    // int nums[]={1,2,3,1};
    int nums[]={1,2,3,1,2,3};

    System.out.println(ContainDup(nums, 2));
  }
  
}