import java.util.ArrayList;
public class CountPairWhooseSumIsLessThanTarget {
  public static int countPair( ArrayList<Integer> nums,int target){
      int count=0;
      for(int i=0;i<nums.size();i++){
        for(int j=i+1;j<nums.size();j++){
          if(nums.get(i)+nums.get(j)<target){
            count++;
          }
        }
      }
      return count;
  }
  public static void main(String[] args) {
    // int nums[]={-1,1,2,3,1};
   ArrayList<Integer> ls=new ArrayList<>();
   ls.add(-1);
   ls.add(1);
   ls.add(2);
   ls.add(3);
   ls.add(1);
   System.out.println(countPair(ls, 2));
  }

}
