public class CountPrime {
  public static int cntprime(int n){
    int count=0;
    int prime[]= new int[n]; //initialize size of prime no 1-to 10;
    for(int i=2;i<n;i++){ //prime no started as 2
      prime[i]=1; //initially marks all as 1
    }
    //inialize prime
    for(int i=2;i*i<n;i++){
      if(prime[i]==1){ //if i is prime
        for(int j=i*i;j<n;j+=i){ //mark of multiple of prime
          prime[j]=0; // multiple of 2 marks as 0 jo prime nhi h usko 0 se mark kre
        }
      }
    }
    //count prime
    for(int i=2;i<n;i++){
      if(prime[i]==1){
        count++;
      }
    }
    return count;
  }
  public static void main(String[] args){
    int n=10;
    System.out.println(cntprime(n));
  }
}