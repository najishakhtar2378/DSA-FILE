import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DiffOfTwoArray {
   public static  List<List<Integer>> findDifference(int[] nums1, int[] nums2) {
        Set<Integer> ls1=new HashSet<>();
        Set<Integer> ls2=new HashSet<>();

        List<List<Integer>> res=new ArrayList<>();
        res.add(new ArrayList<>()); //s1-s2
        res.add(new ArrayList<>()); // s2-s1

        for(int i:nums1){
            ls1.add(i);
        }
        for(int i: nums2){
            ls2.add(i);
        }
        for(int num:ls1){
            if(!ls2.contains(num)){
                res.get(0).add(num);
            }
        }
        for(int num:ls2){
            if(!ls1.contains(num)){
                res.get(1).add(num);
            }
        }
        return res;
    }
  public static void main(String[] args) {
    int nums1[]={1,2,3};
    int nums2[]={2,4,6};
    System.out.println(findDifference(nums1, nums2));
  }
}
