import java.util.Arrays;

public class DuplicateZeros {
  public static int[] DuplicateZeros(int arr[]){
    int n= arr.length;
    int res[]= new int[n+1];
    int j=0;
     for(int i=0;i<n && j<n;i++){
      if(arr[i]==0){
        res[j]=0;
        res[j+1]=0;
        j+=2;
      }else{
        res[j]=arr[i];
        j++;
      }
     }
     return res;
  }
  public static void main(String[] args) {
    int arr[]={1,0,2,3,0,4,5,0};
    int ans[]=DuplicateZeros(arr);
    System.out.println(Arrays.toString(ans));
     
  }
  
}
