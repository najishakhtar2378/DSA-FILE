import java.util.ArrayList;
import java.util.List;
public class FindAllDuplicate {
   public static List<Integer> findDuplicates(int[] nums) {
        List<Integer> ls=new ArrayList<>();
        int n=nums.length;
        for(int i=0;i<n;i++){
            int num=Math.abs(nums[i]); //find number 
            int idx=num-1;  //find idx
            if(nums[idx]<0){ //when idx is -1 all ready visited
               ls.add(num);
            }else{
                nums[idx] *= -1; // if number are not visited then mark -1
            }
        }
        return ls; //store res in list

    }
    public static void main(String[] args) {
      int nums[]={4,3,2,7,8,2,3,1};
      System.out.println(findDuplicates(nums));
    }
  
}
