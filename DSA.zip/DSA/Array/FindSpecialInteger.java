public class FindSpecialInteger {
  public static int findSpecialInt(int nums[]){
    int n=nums.length;
    int tot=n/4;
    for(int i=0;i<n-tot;i++){
      if(nums[i]==nums[i+tot]){
        return nums[i];
      }
    }
    return -1;
  }
  public static void main(String[] args) {
    int nums[]={1,2,2,6,6,6,6,7,10};
    System.out.println(findSpecialInt(nums));
  }
}
