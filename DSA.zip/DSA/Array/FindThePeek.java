import java.util.ArrayList;
import java.util.List;
public class FindThePeek {
  public static List<Integer> FindPeek(int mountains[]){
    List<Integer> ls=new ArrayList<>();
    int n=mountains.length;
    for(int i=1;i<n;i++){
      if(mountains[i]>mountains[i-1] && mountains[i]>mountains[i+1]){
        ls.add(i);
      }
    }
    return ls;
  }
  public static void main(String[] args) {
    int mountains[]={1,4,3,8,5};
    System.out.println(FindPeek(mountains));
  }
}
