import java.util.Arrays;
public  class FindTheXorOfNumsWhichAppearTwice {
  public static int duplicateNumbersXOR(int[] nums) {
      Arrays.sort(nums);
       int xor=0;
       for(int i=0;i<nums.length-1;i++){
         if(nums[i]==nums[i+1]){
            xor=xor^nums[i];
            i++;
         }
       }
       return xor;
}
public static void main(String[] args) {
  int nums[]={1,2,1,2};
  System.out.println(duplicateNumbersXOR(nums));
}
}