public class FirstBadVersion {
  static int bad=4;
  static boolean isBadVersion(int version) {
    return version>= bad;
  }
  public static int FirstBadVersion(int n) {
    int st = 1;
    int end = n;
    int ans = -1;
    while (st <= end) {
      int mid = st + (end - st) / 2;
      if (isBadVersion(mid)) {
        ans = mid;
        end = mid - 1;
      } else {
        st = mid + 1;
      }
    }
    return ans;
  }

  public static void main(String[] args) {
    int n=5;
    System.out.println(FirstBadVersion(n));

  }
  
}
