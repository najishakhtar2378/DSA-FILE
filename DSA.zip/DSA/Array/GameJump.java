public class GameJump {
  public static boolean minJump(int arr[]){
    int jump=0;
    for(int i=0;i<=jump;i++){
      jump=Math.max(jump,i+arr[i]);
      if(jump>=arr.length-1){
        return true;
      }
    }
    return false;
  }
  public static void main(String[] args) {
    int arr[]={3,2,1,0,4};
    int arr1[] = {2,3,1,1,4};
    System.out.println(minJump(arr));
    System.out.println(minJump(arr1));
  }
  
}
