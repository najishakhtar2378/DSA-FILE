public class GasStation {
  public static int GasStat(int gas[],int cost[]){
     int totGas=0;
     int totCost=0;
     int start=0;//starting index when we have start
     int currGas=0;
     for(int i=0;i<gas.length;i++){
        totGas+=gas[i]; //findTotgas
        totCost+=cost[i]; //findTotcost
        //find currGas
        currGas+=(gas[i]-cost[i]);
      //we found starting index
        if(currGas<0){
            start=i+1;
            currGas=0;
        }
     }
     return totGas<totCost?-1:start; 
    }
  public static void main(String[] args) {
    int gas[]={1,2,3,4,5};
    int cost[]={3,4,5,1,2};
    System.out.println(GasStat(gas, cost));
  }
}

