public class H_index {
  public static int hIndex(int citations[]){
    int n=citations.length;
    //create new array size of n+1
    int arr[]=new int[n+1];
    for(int num: citations){
      if(num>n)
        arr[n]++; // when num is greater than size of n then arr[n] will be increases; where n is citations.length
      else
        arr[num]++; // when num is not greater then arr[num]++;
    }
    int count=0;
    for(int i=n;i>=0;i--){
      count=count+arr[i];
      if(count>=i)// jis v position pe index greater than or equal ho jaye tb us index ko return kr denge see example
        return i;
    }
    return 0;
  }
  public static void main(String[] args) {
    int arr[]={3,0,6,7,8,5};
    System.out.println(hIndex(arr));
  }
}
