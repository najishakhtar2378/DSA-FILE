public class H_index2 {
  public static int hindex2(int citations[]){
    int n=citations.length;
    int index=0;
    while(index<n && n-index>citations[index]){
      index++;
    }
    return n-index;
  }
  public static void main(String[] args) {
    int citations[]={0,1,3,5,6};
     //citations are sorted
    //  int citations[] = { 1,1,1,2,2,4,5 };
    System.out.println(hindex2(citations));

  }
}