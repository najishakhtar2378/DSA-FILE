public class HighestAltitude {
  public static int highestAltitude(int gain[]){
    int n=gain.length;
    int sum=0;
    int ans=0;
    for(int i=0;i<n;i++){
      sum+=gain[i];
      ans=Math.max(ans,sum);
    }
    return ans;
  }
  public static void main(String[] args) {
    int gain[]={-4,-3,-2,-1,4,3,2};
      System.out.println(highestAltitude(gain));
  }
}
