public class HouseRobber {
  public static int houseRob(int arr[]){
    // base case 
    if(arr==null || arr.length==0){
      return 0;
    }else if(arr.length==1){
      return arr[0];
    }
    // create dp[]
    int n=arr.length;
    int dp[]=new int[n];
    dp[0]=arr[0]; // if  we have only one house then store dp[0]th idx
    dp[1]=Math.max(arr[0],arr[1]); //if  we have only two house then store dp[1]th idx to find max of arr[0]th idx or arr[1]th idx

    for(int i=2;i<n;i++){
      dp[i]=Math.max(dp[i-2]+arr[i],dp[i-1]);
    }
    return dp[n-1];
  }
  public static void main(String[] args) {
    int arr[]={2,7,9,3,1};
    System.out.println(houseRob(arr));
  }
}