import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class IntersectionArrays {
   public static int[] intersection(int[] nums1, int[] nums2) {
        Arrays.sort(nums1);
        Arrays.sort(nums2);

        int i=0;//nums1
        int j=0;//nums2
        int m=nums1.length;
        int n=nums2.length;
      
       Set<Integer>st=new HashSet<>();
       while(i<m && j<n){
        if(nums1[i]==nums2[j]){
            st.add(nums1[i]);
        while(i<m-1 && nums1[i]==nums1[i+1]){ // when nums[i]==nums[i+1], then i++
            i++;
        }
        while(j<n-1 && nums2[j]==nums2[j+1]){  // when nums[j]==nums[j+1], then j++
            j++;
        }
        i++; //increse nums1 of i
        j++; //increase nums2 of j

       }else if(nums1[i]<nums2[j]){ // when nums1 < nums2 
        i++;
       }else{
        j++;
       }
       }
       //convert set to array
       int res[]=new int[st.size()];//st=size of set
       int setidx=0; //stidx=set index is started from 0
       for(int num:st){
        res[setidx]=num;
        setidx++;
       }
       return res;
       } 
       public static void main(String[] args) {
        int nums1[]={1,2,2,1};
        int nums2[]={2,2};
        IntersectionArrays is=new IntersectionArrays();
       int result[]= is.intersection(nums1, nums2);
       System.out.println(Arrays.toString(result));
        }
       }

