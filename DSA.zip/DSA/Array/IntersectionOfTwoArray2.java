import java.util.ArrayList;
import java.util.Arrays;
public class IntersectionOfTwoArray2 {
  public static int[] intersect2(int nums1[],int nums2[]){
    Arrays.sort(nums1);
    Arrays.sort(nums2);
    int i=0,j=0;
    int m=nums1.length;
    int n=nums2.length;
    ArrayList<Integer>result=new ArrayList<>();
    while(i<m && j<n){
      if(nums1[i]==nums2[j]){
        result.add(nums1[i]);
        i++;
        j++;
      }else if(nums1[i]<nums2[j]){
        i++;
      }else{
        j++;
      }
    }
    int resArr[]=new int[result.size()];
    int residx=0;
    for(int num:result){
      resArr[residx]=num;
      residx++;
    }
    return resArr;
  }
  public static void main(String[] args) {
    int nums1[]={1,2,2,1};
    int nums2[]={2,2};
    IntersectionOfTwoArray2 Is=new IntersectionOfTwoArray2();
    int res[]=Is.intersect2(nums1,nums2);
    System.out.println(Arrays.toString(res));
  }
}
