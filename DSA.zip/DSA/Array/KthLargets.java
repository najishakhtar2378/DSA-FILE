import java.util.PriorityQueue;
public class KthLargets {
   public static int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> pq=new PriorityQueue<>();

        for(int num:nums){
            pq.add(num);
            if(pq.size()>k){
                pq.remove();
            }
        }
        return pq.peek();
  }
    
    public static void main(String[] args) {
      int nums[]={2,3,1,4,5,6};
      System.out.println(findKthLargest(nums, 2));
    }
  
}
