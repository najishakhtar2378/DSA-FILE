public class KthMissingPositiveNumber {
  public static int KthMissing(int nums[],int k){
    int st=0;
    int end=nums.length-1;
    while(st<=end){
      int mid=st+(end-st)/2;
      int missing_No=nums[mid]-(mid+1); //find missing no
      if(missing_No<k){
      st=mid+1;
      }else{
        end=mid-1;
      }
    }
    return st+k;
  }
  public static void main(String[] args) {
    int nums[]={2,3,4,7,11};
    System.out.println(KthMissing(nums, 5));
  }
  
}
