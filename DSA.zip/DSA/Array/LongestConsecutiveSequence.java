import java.util.HashMap;

public class LongestConsecutiveSequence {
    public static int longestConsecutive(int[] nums) {
       HashMap<Integer,Boolean>hm=new HashMap<>();
       // we set all are positive 
       for(int i=0;i<nums.length;i++){
        hm.put(nums[i],true);
       }
        for(int i=0;i<nums.length;i++){
            // when map contains nums[i]<nums[i]-1
            if(hm.containsKey(nums[i]-1)){
                hm.put(nums[i],false);
            }
        }
        // for true keys and find the length of longest consecutive sequence 
        int max=0;
        for(Integer key:hm.keySet()){
            if(hm.get(key)==true){
                max=Math.max(max,findlength(hm,key));
            } 
        }
         return max;
    }
    // find length function 
       private static  int findlength(HashMap<Integer,Boolean>hm,int k){
        int ans=0;
        while(hm.containsKey(k)){
            ans++;
            k++;
        }
         return ans;
       }
       public static void main(String[] args) {
        int nums[]={100,4,200,3,2,1};
        int nums2[]={0,3,7,2,5,8,4,6,0,1};
        System.out.println(longestConsecutive(nums));
        System.out.println(longestConsecutive(nums2));
        
       }
}

