public class LongestContiniousIncreasingSubsequence {
  public static int lICS(int nums[]){
    int max=1;
    int count=1;
    for(int i=1;i<nums.length;i++){
      if(nums[i]>nums[i-1]){
            count++;
      }else{
        max=Math.max(max,count);
        count=1;
      }
    }
    return Math.max(max,count);
  }
  public static void main(String[] args) {
    int nums[]={1,3,5,4,7};
    System.out.println(lICS(nums));
  }
  
}
