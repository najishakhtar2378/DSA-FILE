import java.util.Arrays;
public class LongestHarmoniousSubsequence {
  public static int LHS(int nums[]){
    //using two pointer approach
    Arrays.sort(nums);
    int n=nums.length;
    int i=0;
    int j=1;
    int max=0;
    while(j<n){
      if(nums[j]-nums[i]==1){
        max=Math.max(max,j-i+1);
        j++;
      }else if(nums[j]-nums[i]<1){
        j++;
      }else{
        i++;
      }
    }
    return max;
  }
  public static void main(String[] args) {
    int nums[]={1,3,2,2,5,2,3,7};
    System.out.println(LHS(nums));
  }
}
