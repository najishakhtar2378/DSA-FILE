import java.util.HashMap;
public class LuckyInteger {
  public static int LuckyInt(int nums[]) {
    HashMap<Integer, Integer> hm = new HashMap<>();
    for (int num : nums) {
      hm.put(num, hm.getOrDefault(num, 0) + 1);
    }
    int LuckyInteger = -1;
    for (int key : hm.keySet()) {
      if (hm.get(key) == key) {
        LuckyInteger = key;
      }
    }
    return LuckyInteger;
  }
  public static void main(String[] args) {
    int nums[] = { 1, 2, 2, 3, 3, 3 };
    System.out.println(LuckyInt(nums));
  }
  
}
