import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MajorityElt2 {
  public static List<Integer> majorityElt2(int nums[]){
    List<Integer>ans=new ArrayList<>();
    HashMap<Integer,Integer>hm=new HashMap<>();
    for(int i=0;i<nums.length;i++){
      hm.put(nums[i],hm.getOrDefault(nums[i],0)+1);
    }
    for(Integer key: hm.keySet()){
      if(hm.get(key)>nums.length/3){
        ans.add(key);
      }
    }
    return ans;
  }
  public static void main(String[] args) {
    // int nums[]={3,2,3};
    int nums[] = { 1,2 };

    System.out.println(majorityElt2(nums));
  }
  
}
