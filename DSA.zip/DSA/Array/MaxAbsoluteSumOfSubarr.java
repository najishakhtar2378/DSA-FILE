public class MaxAbsoluteSumOfSubarr {
  public static int maxabs(int nums[]){
    int maxSum=Integer.MIN_VALUE;
    int minSum=Integer.MAX_VALUE;
    int currSum=0;
    int currNegSum=0;
    for(int i=0;i<nums.length;i++){
      currSum=currSum+nums[i];//+ve
      maxSum=Math.max(maxSum,currSum);
      if(currSum<0){
        currSum=0;
      }
      currNegSum =currNegSum+nums[i];
      minSum=Math.min(minSum,currNegSum);
      if(currNegSum>0){
        currNegSum=0;
      }
    }
    return Math.max(maxSum,Math.abs(minSum));
  }
  public static void main(String[] args) {
    int nums[]={1,-3,2,3,-4};
    System.out.println(maxabs(nums));
  }
  
}
