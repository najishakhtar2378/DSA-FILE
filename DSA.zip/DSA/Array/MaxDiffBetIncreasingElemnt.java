public class MaxDiffBetIncreasingElemnt {
  public static int maximumDifference(int[] nums) {
     int n=nums.length;
     int maxSumDiff=-1;
     for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(nums[i]<nums[j]){
               maxSumDiff = Math.max(maxSumDiff,nums[j]-nums[i]); 
            }
        }
     }  
       return maxSumDiff;
}
public static void main(String[] args) {
  int nums[]={1,5,2,10};
  System.out.println(maximumDifference(nums));
}
}
