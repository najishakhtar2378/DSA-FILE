import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MaxNoOfPairArray {
  public static int[] maxNoPair(int nums[]){
    int res[]=new int[2]; //create two size arr res[0] & res[1]
    Set<Integer> hs=new HashSet<>();
    for(int i=0;i<nums.length;i++){
      if(hs.contains(nums[i])){
        hs.remove(nums[i]);
        res[0]++;
      }else{
        hs.add(nums[i]);
      }
    }
    res[1] = hs.size();
    return res;
  }
  public static void main(String[] args) {
    int nums[]={1,3,2,1,3,2,2};
    int ans[]= maxNoPair(nums);
    System.out.println(Arrays.toString(ans));
  }
}
