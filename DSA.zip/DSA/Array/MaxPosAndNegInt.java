public class MaxPosAndNegInt {
  public static int maximumCount(int[] nums) {
    int maxCount = 0;
    int positiveCount = 0;
    int negetiveCount = 0;
    for (int i = 0; i < nums.length; i++) {
      if (nums[i] < 0) {
        negetiveCount++;
      } else if (nums[i] == 0) {
        continue;
      } else {
        positiveCount++;
      }
      maxCount = Math.max(negetiveCount, positiveCount);
    }
    return maxCount;

  }
  public static void main(String[] args) {
    int nums[]={-2,-1,-1,1,2,3};
     System.out.println(maximumCount(nums));
  }
  
}
