public class MaxProductSubArray {
  public static  int maxProduct(int[] nums) {
    int ans= Integer.MIN_VALUE;
    int start=1;
    int end=1;
    int n=nums.length;
    for(int i=0;i<n;i++){
      if(start==0){
        start=1;
      }else if(end==0){
        end=1;
      }
      start=start*nums[i];
      end= end*nums[n-i-1];
      ans= Math.max(ans,Math.max(start,end));
    }
  
    return ans;
  }
  public static void main(String[] args) {
    int nums[]={2,3,-2,4};
    System.out.println(maxProduct(nums));
  }
  
}
