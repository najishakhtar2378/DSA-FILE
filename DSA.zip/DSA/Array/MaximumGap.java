import java.util.Arrays;

public class MaximumGap {
  public static int maxGap(int arr[]){
    int Maxgap=Integer.MIN_VALUE;
    if(arr.length<2){
      return 0;
    }
    Arrays.sort(arr);
    for(int i=0;i<arr.length-1;i++){
      int diff=arr[i+1]-arr[i];
      if(diff>Maxgap){
        Maxgap=diff;
      }
    }
    return Maxgap;

  }
  public static void main(String[] args) {
    int arr[]={3,6,9,1};
    System.out.println(maxGap(arr));
  }
}
