public class MaximumProdOfThreeNumber {
  public static int maximumPrdThreeNum(int nums[]){
    int n=nums.length;
    int ans1=nums[n-1]*nums[n-2]*nums[n-3];
    int ans2=nums[0]*nums[1]*nums[n-1];
    return Math.max(ans1,ans2);
  }
  public static void main(String[] args) {
    int nums[]={-10,-2,1,3,5};
    System.out.println(maximumPrdThreeNum(nums));
  }
  
}
