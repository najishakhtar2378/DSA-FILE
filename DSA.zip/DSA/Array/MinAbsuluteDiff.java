import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MinAbsuluteDiff {
  public static List<List<Integer>> minabs(int arr[]){
    List<List<Integer>> res=new ArrayList<>();
    Arrays.sort(arr);
    int min=Integer.MAX_VALUE;
    for(int i=0;i<arr.length-1;i++){
      int minDiff=arr[i+1]-arr[i];
      if(minDiff<min){
        min=minDiff;
        res.clear();
        res.add(Arrays.asList(arr[i],arr[i+1]));
      }else if(min==minDiff){
        res.add(Arrays.asList(arr[i], arr[i + 1]));
      }
    }
    return res;
  }
  public static void main(String[] args) {
    int arr[]={4,2,3,1};
    System.out.println(minabs(arr));
  }
}
