import java.util.HashSet;
import java.util.Set;

public class MinCommonVal {
  public static int minCommonVal(int nums1[],int nums2[]){
    Set<Integer> st1=new HashSet<>();

    for(int num:nums1){
       st1.add(num);
    }
    for(int num:nums2){
      if(st1.contains(num)){
        return num;
      }
    }
    return -1;

  }
  public static void main(String[] args) {
    int nums1[]={1,2,3};
    int nums2[]={2,4};
    System.out.println(minCommonVal(nums1, nums2));
  }
  
}
