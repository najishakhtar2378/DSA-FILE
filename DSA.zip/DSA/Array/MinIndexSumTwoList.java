import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class MinIndexSumTwoList {
  public static String[] minSumidx(String list1[],String list2[]){
    HashMap<String,Integer> hm=new HashMap<>();
     for(int i=0;i<list1.length;i++){
        hm.put(list1[i],i);
     }
     List<String> res=new ArrayList<>();
     int minSum=Integer.MAX_VALUE;
     for(int i=0;i<list2.length;i++){
       if(hm.containsKey(list2[i])){
        int sum=i+hm.get(list2[i]);
        if(sum<minSum){
          res.clear();
          res.add(list2[i]);
          minSum=sum;
        }else if(minSum==sum){
          res.add(list2[i]);
        }
       }
     }
     return res.toArray(new String[0]);
  }
  public static void main(String[] args) {
    String list1[]={"happy","sad","good"};
    String list2[]={"sad","happy","good"};
    MinIndexSumTwoList ml=new MinIndexSumTwoList();
    String[] ans=ml.minSumidx(list1, list2);
    System.out.println(Arrays.toString(ans));
  }
}
