import java.util.Arrays;
public class MinNoOfGame {
  public static int[] MinNoOfGame(int nums[]){
    int res[]= new int[nums.length];
    Arrays.sort(nums);
    for(int i=0;i<nums.length;i+=2){
       if(nums[i]<nums[i+1]){
        //swap
         int temp=nums[i];
         nums[i]=nums[i+1];
         nums[i+1]=temp;
       }
    }
    int idx=0;
    for(int i=0;i<nums.length;i++){
      res[idx]=nums[i];
      idx++;
    }
    return res;
  }
  public static void main(String[] args) {
    int nums[]={5,4,2,3};
    MinNoOfGame(nums);
     System.out.println(Arrays.toString(nums));
  }
}
