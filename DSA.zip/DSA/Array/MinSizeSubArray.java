public class MinSizeSubArray {
  public static int minSizeSub(int nums[],int target){
  int i=0;
  int j=0;
  int sum=0;
  int minL=Integer.MAX_VALUE;
  int n=nums.length;
  while(j<n){
    sum+=nums[j];
    while(sum>=target){ //window size decrease
      minL=Math.min(minL,j-i+1);
      sum-=nums[i];
      i++;
    }
    j++;
  }
  return minL==Integer.MAX_VALUE?0:minL;
}
  public static void main(String[] args) {
    int nums[]={2,3,1,2,4,3};
    System.out.println(minSizeSub(nums, 7));
  }
  
}
