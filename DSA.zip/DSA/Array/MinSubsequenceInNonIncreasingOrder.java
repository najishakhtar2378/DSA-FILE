import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MinSubsequenceInNonIncreasingOrder {
   public static List<Integer> minSubsequence(int[] nums) {
        ArrayList<Integer> res= new ArrayList<>();
        Arrays.sort(nums);
        //find TotalSum
        int totalSum=0;
        for(int num:nums){
            totalSum+=num;
        }
        //find currSum HalfSum and minSubsequence
        int currSum=0;
        int halfSum=totalSum/2;
        //reverse loop using 
        for(int i=nums.length-1;i>=0;i--){
            currSum+=nums[i];
            res.add(nums[i]);
            //check currSum>halfSum then break to loop
            if(currSum>halfSum){
                break;
            }
        }
         return res;
    }
    public static void main(String[] args) {
      int nums[]={4,3,10,9,8};
      System.out.println(minSubsequence(nums));
    }
  
}
