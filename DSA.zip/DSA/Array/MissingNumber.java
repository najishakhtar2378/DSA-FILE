public class MissingNumber {
  public static int missingNum(int nums[]){
    // xor method
    // int allXOR=0;
    // for(int i=0;i<nums.length;i++){
    //   allXOR=allXOR^i;
    // }
    // for(int num:nums){
    //   allXOR=allXOR^num;
    // }
    // return allXOR;
  // }
    // brute force approach;
    int n= nums.length;
    int SumOfn= n*(n+1)/2; //total sum of range[0-9]
    int actualSum=0; // total sum of nums[i];
    for(int i=0;i<n;i++){
      actualSum=actualSum+nums[i];
    }
    return SumOfn-actualSum;
  }

  public static void main(String[] args) {
    int nums[]={3,0,1};
    System.out.println(missingNum(nums));
  }
  
}
