public class MovesZero {
  public static void movesZero(int nums[]){
    int index=0;
    for(int i=0;i<nums.length;i++){
      if(nums[i]!=0){ // jab nums ke i par zero na ho tb index ko update krenge nums[i]se
        nums[index]=nums[i];
        index++;
      }
    }
    // change nums[index] from 0
    for(int i=index;i<nums.length;i++){
      nums[i]=0; //replace all i to 0
    }
  }
  public static void main(String[] args) {
    int nums[]={1,0,0,2,5,0};
     movesZero(nums);
    for(int i=0;i<nums.length;i++){
      System.out.print(nums[i]+" ");
    }
  }
  
}
