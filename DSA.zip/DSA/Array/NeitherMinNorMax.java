import java.util.Arrays;
public class NeitherMinNorMax {
  public static int minMax(int nums[]){
    int  n=nums.length;
    Arrays.sort(nums);
    if(n>2){
      int mid=n/2;
      return nums[mid];
    }
    return -1;
  }
  public static void main(String[] args) {
    int nums[]={3,2,1,4};
    System.out.println(minMax(nums));
  }
}
