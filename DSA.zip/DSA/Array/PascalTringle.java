import java.util.ArrayList;
import java.util.List;

public class PascalTringle {
  public static List<List<Integer>> pascal(int numRows){
    List<List<Integer>>res= new ArrayList<>();
    if(numRows==0){
      return res;
    }
    res.add(new ArrayList<>());
    res.get(0).add(1);
    for(int i=1;i<numRows;i++){
      List<Integer> curr=new ArrayList<>();
      curr.add(1);
      for(int j=1;j<i;j++){
        curr.add(res.get(i-1).get(j-1)+res.get(i-1).get(j));
        // where i-1 repersents list me kitne  element ko fill kiya ja sakta h  jabki (j-1)+(j)  dono upper wale jth postion ko add krke list me fill kre 
//         1 // curr.add(1)
//       1  1   // curr.add(1) and j(0)+j(1)=2
//      1 2  1
//   1  3   3   1
// 1  4   6   4  1 
      }
       curr.add(1);
       res.add(curr);
      }
      return res;

    }
    public static void main(String[] args) {
      System.out.println(pascal(5));
    }
  }
  

