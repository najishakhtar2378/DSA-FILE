public class PeakIndexInMountainArr {
  public static int  peekIndex(int arr[]){
  int st = 0;
  int end=arr.length-1;while(st<=end){
    int mid=st + (end-st) / 2;
    if (arr[mid+1]<arr[mid] && arr[mid-1]<arr[mid]) {
      return mid;
    } else if (arr[mid + 1] < arr[mid]){
      end = mid;
    } else {
      st = mid + 1;
    }
  }return st;
}
public static void main(String[] args) {
  int arr[]={0,2,1,0};
  System.out.println(peekIndex(arr));
}
}