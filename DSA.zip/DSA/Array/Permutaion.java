import java.util.ArrayList;
import java.util.List;

public class Permutaion {
    public static void GetPer(int arr[],int idx,List<List<Integer>>ans){
    if(idx==arr.length){
      List<Integer>temp=new ArrayList<>();
      for(int i:arr){
        temp.add(i);
      }
      ans.add(temp);
      return;
    }
    for(int i=idx;i<arr.length;i++){
      swap(arr,i,idx); // before goes down and call getper
      GetPer(arr,idx+1,ans);
      swap(arr,i,idx); // after backtracking time return in original form
    }
    }
    public static void swap(int arr[],int i,int j){
      int var=arr[i];
      arr[i]=arr[j];
      arr[j]=var;
    }
    public static List<List<Integer>> permute(int[] arr) {
         List<List<Integer>>ans=new ArrayList<>();
         GetPer(arr,0,ans);
        return ans;
    }
  public static void main(String[] args) {
    int arr[]={1,2,3};
    System.out.print(permute(arr));
  }
}
