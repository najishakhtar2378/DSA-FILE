public class Plindrome {
  public static boolean isPalindrome(int x) {
    // convert array to string
    String s = String.valueOf(x);
    int n = s.length();
    // itterate half of string
    for (int i = 0; i < s.length() / 2; i++) {
      if (s.charAt(i) != s.charAt(n - i - 1)) {
        return false;
      }
    }
    return true;
  }
  public static void main(String[] args) {
    int x[]={1,2,1};
   
  }
}
