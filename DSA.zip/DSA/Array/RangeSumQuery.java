public class RangeSumQuery {
  public static int prefixSum[] = null;
  public void NumArray(int[] nums) {
        int n=nums.length;
        prefixSum =new int[n];
        prefixSum[0]=nums[0];
        for(int i=1;i<n;i++){
           prefixSum[i]=nums[i]+prefixSum[i-1];
        }
    }

  public int sumRange(int left, int right) {
    if (left == 0) {
      return prefixSum[right];
    } else {
      return prefixSum[right] - prefixSum[left - 1];
    }
  }
  public static void main(String[] args) { 
    
  }
  
}
