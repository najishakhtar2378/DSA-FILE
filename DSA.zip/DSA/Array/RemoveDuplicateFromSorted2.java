public class RemoveDuplicateFromSorted2 {
  public static int remove(int nums[]){
    int i=0;
    for(int val:nums){
      if(i<2 ||val!=nums[i-2]){
        nums[i++]=val;
      }
    }
    return i;
  }
  public static void main(String[] args) {
    int nums[]={0,0,1,1,1,2,2,3};
    System.out.print(remove(nums));
  }
}
