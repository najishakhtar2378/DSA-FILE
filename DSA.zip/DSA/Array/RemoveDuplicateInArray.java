public class RemoveDuplicateInArray {
  public static int removeDup(int arr[]){
    int count=0;
    for(int i=0;i<arr.length;i++){
      // check the condition if condition is true then continue 
      if(i<arr.length-1 && arr[i]==arr[i+1]){
        continue;
        // save the element in count 
      }else{
        arr[count]=arr[i];
        count++;
      }
    }
    return count;
  }
  public static void main(String[] args) {
    // int arr[]={1,1,2,2};
    int arr[]={0,0,1,1,1,2,2,3,3,4};
    System.out.println(removeDup(arr));
  }
  
}
