public class SearchInsertPosition {
  public static int searchPos(int arr[],int tar){
    int st=0;
    int end=arr.length-1;
    while(st<=end){
      int mid=st+(end-st)/2;
      if(arr[mid]==tar){
        return mid;
      }else if(arr[mid]>tar){
        end =mid-1;
      }else{
        st=mid+1;
      }
    }
    return st;
  }
  public static void main(String[] args) {
    int arr[]={1,3,5,6};
    System.out.println(searchPos(arr, 2));
  }
}
