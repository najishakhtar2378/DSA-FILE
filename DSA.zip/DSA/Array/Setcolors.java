public class Setcolors {
  public static void sortColors(int[] nums){
    for (int turn=0;turn<nums.length;turn++){
      for (int j=0; j<nums.length-1-turn; j++){
        if (nums[j]>nums[j+1]){
          int temp=nums[j];
          nums[j]=nums[j+1];
          nums[j+1]=temp;
        }
      }
    }
    return;
  }
  public static void printSc(int nums[]){
    for (int i = 0; i < nums.length; i++) {
      System.out.print(nums[i] + " ");
    }
  }
  public static void main(String[] args) {
    int nums[]={2,0,2,1,1,0};
    sortColors(nums);
     printSc(nums);
  }
  
}
