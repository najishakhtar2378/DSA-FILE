public class SingleDuplicateNo {
  public static  int singleNonDuplicate(int[] nums) {
    int st = 0;
    int end = nums.length - 1;
    while (st < end) {
      int mid = (st + end) / 2;
      if (mid % 2 == 1) {
        mid--; // ensure mid is always even
      }
      if (nums[mid] == nums[mid + 1]) {
        st = mid + 2; // single element lies to the right
      } else {
        end = mid; // single element lies at mid or left side
      }
    }
    return nums[st];
  }
  public static void main(String[] args) {
    int nums[]={1,1,2,3,3,4,4,8,8};
    System.out.println(singleNonDuplicate(nums));
  }
  
}
