import java.util.Arrays;
public class SortArrayParity {
  public static int[] sortParity(int nums[]){
    int res[] = new int[nums.length];
    int evenidx = 0;
    int oddidx = nums.length - 1;
    for (int num : nums) {
      if (num % 2 == 0) {
        res[evenidx] = num;
        evenidx++;
      } else {
        res[oddidx] = num;
        oddidx--;
      }
    }
    return res;
  }
  public static void main(String[] args) {
    int nums[]={3,1,2,4};
    sortParity(nums);
    System.out.println(Arrays.toString(nums));
  }
  
}
