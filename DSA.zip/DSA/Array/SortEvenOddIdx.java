import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortEvenOddIdx {
  public static int[] evenOdd(int nums[]){
    List<Integer>l1=new ArrayList<>();
    List<Integer> l2 = new ArrayList<>();
    for(int i=0;i<nums.length;i++){
      if(i%2==0){
        l1.add(nums[i]);
      }else{
        l2.add(nums[i]);
      }
    }
    Collections.sort(l1);
    Collections.sort(l2);
    int j=0;
    int k=l2.size()-1;
    for(int i=0;i<nums.length;i++){
      if(i%2==0){
        nums[i]=l1.get(j);
        j++;
      }else{
        nums[i]=l2.get(k);
        k--;
      }
    }
    return nums;

  }
  public static void main(String[] args) {
    int nums[]={4,1,2,3};
    evenOdd(nums);
    System.out.println(Arrays.toString(nums));
  }
  
}
