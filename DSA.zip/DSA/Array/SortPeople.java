import java.util.Arrays;
import java.util.HashMap;
public class SortPeople {
  public static String[] sortPeople(String[] names,int heights[]){
  HashMap<Integer,String> hm=new HashMap<>();
  for(int i=0;i<names.length;i++){
    hm.put(heights[i],names[i]);
  }
    Arrays.sort(heights);
    int idx=0;
    String[] res=new String[heights.length];
    for(int i=0;i<heights.length;i++){
      res[idx]=hm.get(heights[i]);
    }
    return res;
  }
  public static void main(String[] args) {
    String [] names={"Mary","John","Emma"};
    int heights[]={155,185,150};
    System.out.println(sortPeople(names, heights));
  }
  
}
