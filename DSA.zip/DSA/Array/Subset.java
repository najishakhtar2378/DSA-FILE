import java.util.ArrayList;
import java.util.List;

public class Subset {
   public static void subs(int arr[],int i,List<Integer>curr,List<List<Integer>>ans){
        if(i==arr.length){
            ans.add(new ArrayList<>(curr));
            return;
        }
        curr.add(arr[i]);
        subs(arr,i+1,curr,ans);
        curr.remove(curr.size()-1);
        subs(arr,i+1,curr,ans);
    }
    public static List<List<Integer>> subsets(int[] arr) {
        List<Integer>curr =new ArrayList<Integer>();
        List<List<Integer>>ans=new ArrayList<>();
        subs(arr,0,curr,ans);
        return ans;
    }
    public static void main(String[] args) {
      int arr[]={1,2,3};
      System.out.println(subsets(arr));
    }
}
