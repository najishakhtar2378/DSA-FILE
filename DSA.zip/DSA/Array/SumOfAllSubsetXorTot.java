public class SumOfAllSubsetXorTot {
  public static int subsetXORSum(int[] arr) {
    return rec(arr,0, 0);
  }
  public static int rec(int arr[], int i, int currentXor) {
    if (i==arr.length) {
      return currentXor;
    }
    int include=rec(arr,i+1,currentXor^arr[i]);
    int exclude=rec(arr,i+1,currentXor);
    return include+exclude;
  }
  public static void main(String[] args) {
    int arr[]={1,3};
    System.out.println(subsetXORSum(arr));
  }
}
