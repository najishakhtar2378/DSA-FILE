import java.util.ArrayList;
import java.util.List;

public class SummaryRange {
  public static List<String> SummaryRange(int nums[]){
    int n=nums.length;
    List<String>ans=new ArrayList<>();
    for(int i=0;i<n;i++){
      int start=nums[i];
      while(i+1<n && nums[i+1]-nums[i]==1){
        i++;
      }
      if(start!=nums[i]){ //when range are occurs between two possible nums
        ans.add(String.valueOf(start)+"->"+ String.valueOf(nums[i]));

      }else{
        ans.add(String.valueOf(start));//when range are not occurs b/w two possible nums
      // assume : start=a
      // nums[i]=b  
      // [ a!=b] then a->b  if it is not possible then use else condition
      }
    }
    return ans;
    
  }
  public static void main(String[] args) {
    int nums[]={0,1,2,4,6,7,9};
    System.out.println(SummaryRange(nums));
  }
  
}
