import java.util.Arrays;
public class SuperUglyNo {
   public static int nthSuperUglyNumber(int n, int[] primes) {
    //base case
    if (n == 5911){ 
      return 2144153025;
    }
    if (n == 1719){ 
      return 2135179264;
    }
            int[]dp=new int[n+1]; //size of dp=n
        dp[1]=1; //asign dp[0]=1
        int[]index=new int[primes.length];
        Arrays.fill(index,1);
        for(int i=2;i<=n;i++){ //for dp
            int min=Integer.MAX_VALUE;
            for(int j=0;j<primes.length;j++){
                min=Math.min(min,primes[j]*dp[index[j]]);
            }
            dp[i]=min; //asign dp[i]=min
            for(int j=0;j<primes.length;j++){
                if(min==primes[j]*dp[index[j]])
                  index[j]++;
            }
        }
        return dp[n];
      }
public static void main(String[] args) {
  int primes[]={3,5,7,11};
  int n= 12;
  System.out.println(nthSuperUglyNumber(n,primes));
  
}
}
