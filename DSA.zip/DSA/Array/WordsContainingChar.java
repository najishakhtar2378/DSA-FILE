import java.util.ArrayList;
import java.util.List;
public class WordsContainingChar {
      public static List<Integer> findWordsContaining(String[] words, char k) {
        List<Integer> ans=  new ArrayList<>();
        int wordIdx=0;
        //using for each loop 
        for(String s:words){
            for(int i=0;i<s.length();i++){
                if(s.charAt(i)==k){
                    ans.add(wordIdx);
                    break;
                }
            }
            wordIdx++;
           
        }
        return ans;
       
    }
    public static void main(String[] args) {
      String words[] = {"leet" ,"code"};
     
     System.out.println(findWordsContaining(words, 'e'));
      
    }
}
