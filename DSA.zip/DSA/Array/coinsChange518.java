public class coinsChange518 {
  public static int change(int sum, int[] coins) {
    int n = coins.length;
    int dp[][] = new int[n + 1][sum + 1];
    // initialization
    // i->coins
    for (int i = 0; i < n + 1; i++) {
      dp[i][0] = 1; // i have coins but no give sum
    }
    // j->sum
    for (int j = 1; j < sum + 1; j++) {
      dp[0][j] = 0; // bcz i have no coins then sum is not possible
    }
    for (int i = 1; i < n + 1; i++) {
      for (int j = 1; j < sum + 1; j++) {
        if (coins[i - 1] <= j) { // include case jab coins more hoga or sum kam hoga
          dp[i][j] = dp[i][j - coins[i - 1]] + dp[i - 1][j]; // give total way
        } else {
          dp[i][j] = dp[i - 1][j];// exclude case
        }
      }
    }
    return dp[n][sum];
  }
  public static void main(String[] args) {
    int coins[]={1,2,5};
    System.out.println(change(11, coins));
  }
  
}
