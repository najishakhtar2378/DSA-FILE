import java.util.Arrays;

public class countElementsWithStrictlySmallerAndGreaterElements {
   public static int countElements(int[] nums) {
        Arrays.sort(nums);
        int count=0;
        for(int i=1;i<nums.length-1;i++){
            if(nums[i]>nums[0] && nums[i]<nums[nums.length-1]){
                count++;
            }
        }
        return count;
    }
    public static void main(String[] args) {
      int nums[]={2,7,11,15};
      System.out.println(countElements(nums));
    }
}
