import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
public class findAllNumberDisapearedInArr {
   public static List<Integer> findDisappearedNumbers(int[] nums) {
        int n=nums.length;
        HashSet<Integer>hs=new HashSet<>();
        List<Integer> ls=new ArrayList<>();
    
        for(int num:nums){
            hs.add(num);
        }
        for(int i=1;i<=n;i++){ // i=1 to 8 tak loop chlega
            if(!hs.contains(i)){ // 1 se 8 tk me elemnt store nhi hoga uske store krenge
                ls.add(i);
            }
        }
        return ls;
    }
    public static void main(String[] args) {
        int nums[]={4,3,2,7,8,2,3,1};
        System.out.println(findDisappearedNumbers(nums)); //missing no 5 & 6
      
    }
  
}
