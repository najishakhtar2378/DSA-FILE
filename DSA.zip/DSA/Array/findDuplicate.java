import java.util.HashSet;

public class findDuplicate {
  public static int findDup(int nums[]){
    // Arrays.sort(nums);
    // usin array
    // for(int i=0;i<nums.length;i++){
    //   if(nums[i]==nums[i+1]){
    //     return nums[i];
    //   }
    // }
    // return -1;
    
    //using hash set
    HashSet<Integer>s=new HashSet<>();
    for(int i=0;i<nums.length;i++){
      if(s.contains(nums[i])){
        return nums[i];
      }
      s.add(nums[i]);
    }
    return -1;
  }
  public static void main(String[] args) {
    int nums[]={1,3,4,5,2,2};
    System.out.println(findDup(nums));
  }
  
}
