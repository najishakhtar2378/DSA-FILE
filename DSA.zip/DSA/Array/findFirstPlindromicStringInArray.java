public class findFirstPlindromicStringInArray {
  public static  String firstPalindrome(String[] words) {
    for (String s : words) {
      if (isPlindrome(s)) {
        return s;
      }
    }
    return "";

  }

  // check palindrome
  public static  boolean isPlindrome(String c) {
    int i = 0;
    int j = c.length() - 1;
    if (c.charAt(i) != c.charAt(j)) {
      i++;
      j--;
      return false;
    }
    return true;
  }
  public static void main(String[] args) {
    String words[]={"abc","car","ada","racecar","cool"};
    System.out.println(firstPalindrome(words));
  }
  
}
