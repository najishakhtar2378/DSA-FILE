import java.util.ArrayList;
import java.util.List;

public class findIndicecOfStableMountains {
  public static List<Integer> stableMountain(int height[],int threshold){
      List<Integer> ls=new ArrayList<>();
      for(int i=1;i<height.length;i++){
        if(height[i-1]>threshold){
          ls.add(i);
        }
      }
      return ls;
  }
  public static void main(String[] args) {
    int height[]={1,2,3,4,5};
    int threshold=2;
    System.out.println(stableMountain(height, threshold));
  }
}
