public class findMinimumOprationsTomakeAllElementDivisibleByThree {
   public static int minimumOpration(int nums[]){
     int n=nums.length;
     int count=0;
     for(int i=0;i<n;i++){
      int rem=nums[i]%3;
       if(rem>0){
          count++;
       }
     }
     return count;
   }
   public static void main(String[] args) {
     int nums[]={1,2,3,4};
     System.out.println(minimumOpration(nums));
   }
  
}
