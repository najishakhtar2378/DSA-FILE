public class firstlastsortedArray {
  public static int[] SearchArr(int nums[], int tar){
    int first=findPos(nums,tar,true);
    int last=findPos(nums,tar,false);
    return new int[]{ first,last};
    }
    public static int findPos(int nums[],int tar, boolean findFirst){
      int st=0;
      int end=nums.length-1;
      int ans= -1;
      while(st<=end){
        int mid=st+(end-st)/2;
        if(nums[mid]==tar){
          ans=mid;
          if(findFirst){
            end=mid-1;
          }else{
            st=mid+1;
          }
        }else if(nums[mid]<tar){
          st=mid+1;
        }else{
          end=mid-1;
        }
      }
      return ans;
    }
    public static void main(String[] args) {
      int nums[]={5,7,7,8,8,10};
      System.out.println(findPos(nums, 8,true));
      
    }
  
}

//dry run
// first 
// Step 2:findPos(nums,8,true)→

// find first
// index

// Initialize:st=0,end=5,ans=-1

// Loop 1:

// mid=0+(5-0)/2=2

// nums[2]=7<8→st=mid+1=3

// Loop 2:

// mid=3+(5-3)/2=4

// nums[4]=8==tar→ans=4

// Since findFirst=true, move left→end=mid-1=3

// Loop 3:

// mid=3+(3-3)/2=3

// nums[3]=8==tar→ans=3

// Move left again→end=mid-1=2

// Loop ends (st=3, end=2)
// 👉 Return 3

// Step 3:findPos(nums,8,false)→

// find last
// index

// Initialize:st=0,end=5,ans=-1

// Loop 1:

// mid=0+(5-0)/2=2

// nums[2]=7<8→st=3

// Loop 2:

// mid=3+(5-3)/2=4

// nums[4]=8==tar→ans=4

// Since findFirst=false, move right→st=mid+1=5

// Loop 3:

// mid=5+(5-5)/2=5

// nums[5]=10>8→end=mid-1=4

// Loop ends (st=5, end=4)
// 👉 Return 