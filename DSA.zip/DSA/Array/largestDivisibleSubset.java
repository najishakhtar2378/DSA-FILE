import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class largestDivisibleSubset {
    static List<Integer>res; // final res
    static int[] dp;
    public static List<Integer> largestDivisibleSubset(int[] nums) {
      Arrays.sort(nums);
      res=new ArrayList<>();
      dp=new int[nums.length];
       Arrays.fill(dp,-1);
       LDShelper(nums,0,new ArrayList<>(),1);
       return res;
    }
    public static void LDShelper(int nums[],int start,List<Integer>curr,int prev){
        if(curr.size()>res.size()){
        res=new ArrayList<>(curr);
        System.out.println(res);
        }
       for(int i=start;i<nums.length;i++){
        if( curr.size()>dp[i]&&nums[i]%prev==0){
            dp[i]=curr.size();
            curr.add(nums[i]);
            LDShelper(nums,i+1,curr,nums[i]);//prev->nums[i] divisivle time
            curr.remove(curr.size()-1);
        }
    }
}
public static void main(String[] args) {
  int nums[]={1,2,3};
  largestDivisibleSubset(nums);

  
}
  
}
