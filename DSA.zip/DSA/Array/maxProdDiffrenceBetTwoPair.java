import java.util.Arrays;

public class maxProdDiffrenceBetTwoPair {
  public static int maxProdDiff(int nums[]){
    int n=nums.length;
    Arrays.sort(nums);
    int ans1=nums[n-1]*nums[n-2]; // last two pair 
    int ans2=nums[0]*nums[1]; //starting two pair
    return ans1-ans2;
  }
  public static void main(String[] args) {
    int nums[]={5,6,2,7,4};
    System.out.println(maxProdDiff(nums));
  }
}
