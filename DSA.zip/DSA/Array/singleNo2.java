public class singleNo2 {
  public static int singleNumber(int[] nums) {
    int ans = 0;
    for (int i = 0; i < 32; i++) {
      int sum = 0; // it contains total 1 value
      for (int j = 0; j < nums.length; j++) {
        if(((nums[j] >> i) & 1) == 1)// it is used to comapre value is 1 or not
          sum++; // if value get equal of 1 then increased the sum variable
      }
      sum%=3;
      // set the value of 0 in 1
      if(sum != 0){
        // set 0 in 1
        ans |= sum << i;
      }
    }
    return ans;
  }
  public static void main(String[] args) {
    int nums[]={4,4,4,2,2,2,1,3,3,3};
    System.out.println(singleNumber(nums));
  }
  
}
