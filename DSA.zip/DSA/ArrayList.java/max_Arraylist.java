
import java.util.ArrayList;
public class max_Arraylist {
    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<>();
        ArrayList<String> list1=new ArrayList<>();
        ArrayList<Boolean> list2=new ArrayList<>();
        // Add opration;
        list.add(2);
        list.add(5);
        list.add(3);
        list.add(9);
        list.add(8);

        // int max=Integer.MIN_VALUE;
        int min=Integer.MAX_VALUE;
        for(int i=0;i<list.size();i++){
            // max=Math.max(max, list.get(i));
                min=Math.min(min, list.get(i));
        }
        // System.out.println(max);
        System.out.println(min);
}
}