
import java.util.ArrayList;
public class opration {
    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<>();
        ArrayList<String> list1=new ArrayList<>();
        ArrayList<Boolean> list2=new ArrayList<>();
        // Add opration;
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        System.out.println(list);
     
        // get element
        int element=list.get(2);
         System.out.println(element);

        // // Remove
        // list.remove(2);
        // System.out.println(list );

        // set
        // list.set(2, 10);
        // System.out.println(list);

        // contains
        System.out.println(list.contains(1));
        System.out.println(list.contains(11));

        // list size

        System.out.println(list.size());

        // print arrayList
        for(int i=0;i<list.size();i++){
            System.out.print(list.get(i)+" ");
        }
        System.out.println();


    }
    
}
