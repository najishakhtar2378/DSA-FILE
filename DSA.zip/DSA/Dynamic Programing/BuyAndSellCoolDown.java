import java.util.Arrays;

public class BuyAndSellCoolDown {
      public static  int buyStock(int prices[],int day,int n,boolean buy,int dp[][]){
        if(day>=n){
        return 0;
    }
    if(dp[day][buy==true?1:0]!=-1){
        return dp[day][buy==true?1:0];
    }
    int profit=0;
    if(buy==true){ // if we are buying we have 2 options, either take it or not
      // if we take it, means we are buying, so next we will sell it,so our buystock is
      // for sell, it will return sell price
      // prices[day] is the buy price, so profit = sell price - buy price
        int take=buyStock(prices,day+1,n,false,dp) - prices[day];
        // if we do not take it, then means next day we have to buy it, so we will call
        // buyStock for buy, that's why we pass true
        int not_take=buyStock(prices,day+1,n,true,dp); //buying

        profit=Math.max(profit,Math.max(take,not_take));
    }else{
      // for sell also we have 2 options, either we can sell on that day, or not sell
      // if we sell on that day, then we will get some money + next we will buy only
      // but not next day bcz next day is Cooldown, so we will buy on i+2 th day
        int sell=prices[day]+buyStock(prices,day+2,n,true,dp);
        // if we are not selling than, we will sell next day, we cannot buy before
        // selling so we will pass false
        int not_sell=buyStock(prices,day+1,n,false,dp);
   // find maxprofit
        profit=Math.max(profit,Math.max(sell,not_sell));
    } 
    return dp[day][buy==true?1:0]=profit;

    }
  
    public static int maxProfit(int[] prices) {
        int n=prices.length;
        boolean buy=true; ////on the first day we will buy only
        int dp[][]=new int[n+1][2]; ////in Brute force Approach we have 2 changing variables - day and buy
        // for buy we have 2 options true or false ->[day][buy]
        for(int [] i:dp)
             Arrays.fill( i,-1); // //initialize dp array with -1
        return buyStock(prices,0,n,true,dp);
    
    }
    public static void main(String[] args) {
      int prices[]={1,2,3,0,2};
      System.out.println(maxProfit(prices));
    }
  
}
