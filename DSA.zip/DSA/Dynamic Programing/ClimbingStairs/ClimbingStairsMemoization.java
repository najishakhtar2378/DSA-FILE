package ClimbingStairs;
import java.util.Arrays;

public class ClimbingStairsMemoization {
  public static int CountWays(int n,int ways[]){
    if(n==0){
      return 1;
    }
    if(n<0){
      return 0;
    }
    if(ways[n]!=-1){ // already calculated value of n
      return ways[n];
    }
    ways[n]=CountWays(n-1, ways)+CountWays(n-2, ways);
    return ways[n];
  }
  public static void main(String[] args) {
    int n=5;
    int ways[]=new int[n+1];
    Arrays.fill(ways, -1);
    // in a arrays all places are fill to -1 -1 -1 -1
    System.out.println(CountWays(n, ways));
   
  }
  
}
