import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PetStore extends Frame implements ActionListener {
  private Image catImage;
  private Image beagleImage;
  private Image poodleImage;
  private Image persianImage;
  private Image sphynxImage;
  private Image currentImage;

  public PetStore() {
    // Load images
    catImage = Toolkit.getDefaultToolkit().getImage("cat.jpeg");
    beagleImage = Toolkit.getDefaultToolkit().getImage("beagle.jpeg");
    poodleImage = Toolkit.getDefaultToolkit().getImage("poodle.jpeg");
    persianImage = Toolkit.getDefaultToolkit().getImage("PersianCat.jpg");
    sphynxImage = Toolkit.getDefaultToolkit().getImage("SphynxCat.jpg");

    // Set up the frame
    setTitle("Pet Store");
    setSize(400, 400);
    setLayout(new BorderLayout());
    setBackground(Color.LIGHT_GRAY);

    // Create menu bar
    MenuBar menuBar = new MenuBar();
    Menu menu = new Menu("Select Pet");
    // MenuItem catItem = new MenuItem("Cat");
    // MenuItem dogItem = new MenuItem("Dog");

    // Create a submenu for dog breeds
    Menu dogSubMenu = new Menu("Dog Breeds");
    MenuItem beagleItem = new MenuItem("Beagle");
    MenuItem poodleItem = new MenuItem("Poodle");

    // Sub menu for cat breeds
    Menu catSubMenu = new Menu("Cat Breeds");
    MenuItem persianItem = new MenuItem("Persian");
    MenuItem sphynxItem = new MenuItem("Sphynx");

    // Add action listeners
    // catItem.addActionListener(this);
    // dogItem.addActionListener(this);
    persianItem.addActionListener(this);
    sphynxItem.addActionListener(this);
    beagleItem.addActionListener(this);
    poodleItem.addActionListener(this);

    // Add items to the menus
    // menu.add(catItem);
    // menu.add(dogItem);
    catSubMenu.add(persianItem);
    catSubMenu.add(sphynxItem);
    dogSubMenu.add(beagleItem);
    dogSubMenu.add(poodleItem);
    menu.add(dogSubMenu); // Add dog breeds submenu to the main menu
    menu.add(catSubMenu);
    menuBar.add(menu);
    setMenuBar(menuBar);

    // Set up text
    Label welcomeLabel = new Label("Welcome to Pet Store", Label.CENTER);
    welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
    welcomeLabel.setForeground(Color.BLUE);
    add(welcomeLabel, BorderLayout.NORTH);

    // Add a window listener for closing
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    // Make the frame visible
    setVisible(true);
  }

  public void paint(Graphics g) {
    if (currentImage != null) {
      g.drawImage(currentImage, 70, 100, this);
    }
  }

  public void actionPerformed(ActionEvent e) {
    MenuItem source = (MenuItem) e.getSource();
    if (source.getLabel().equals("Persian")) {
      currentImage = persianImage;
    } else if (source.getLabel().equals("Sphynx")) {
      currentImage = sphynxImage;
    } else if (source.getLabel().equals("Beagle")) {
      currentImage = beagleImage;
    } else if (source.getLabel().equals("Poodle")) {
      currentImage = poodleImage;
    }
    repaint();
  }

  public static void main(String[] args) {
    new PetStore();
  }
}


  

