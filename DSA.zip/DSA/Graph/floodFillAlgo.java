public class floodFillAlgo {

  // leetCode problem
  // time complexity O(m*n)
  public void helper(int image[][],int sr,int sc,int col,boolean vis[][],int orgCol){
    if(sr<0||sc<0||sr>=image.length||sc>=image[0].length||vis[sr][sc]||image[sr][sc]!=orgCol){
      return;
    }
    helper(image, sr, sc-1, col, vis, orgCol);
    helper(image, sr, sc+1, col, vis, orgCol);
    helper(image, sr-1, sc, col, vis, orgCol);
    helper(image, sr+1, sc, col, vis, orgCol);

  }

  public int[][] floodFill(int [][] image,int sr,int sc,int col){
    boolean vis[][]=new boolean[image.length][image[0].length];
    helper(image, sr, sc, col, vis, image[sr][sc]);
    return image;
  
  }

  public static void main(String[] args) {
    int image[][]={{1,1,1},
                    {1,1,0},
                     {1,0,1}};
  }
  
}
