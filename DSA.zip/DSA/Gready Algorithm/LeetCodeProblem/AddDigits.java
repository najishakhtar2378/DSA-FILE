
public class AddDigits {
  public static int AddDigits(int nums){
    if(nums==0){
      return 0;
    }
    return 1+(nums-1)%9;
  }
  public static void main(String[] args) {
    int nums=38;
    System.out.println(AddDigits(nums));
  }
}
