public class AlternatingDigits {
  public static int AlternatingDigit(int nums){
    int sum=0;
    int numDigit=0;
    while(nums>0){
      int digit=nums%10;
      sum+=digit*(numDigit%2==0?1:-1);
      nums=nums/10;
      numDigit++;
    }
    return numDigit%2==0?sum*-1:sum;
  }
  public static void main(String[] args) {
    int nums=521;
    System.out.println(AlternatingDigit(nums));

  }
  
  
}
