import java.util.Arrays;

public class BuyTwoChoclates {
  public static int BuyChoclate(int prices[],int money){
    Arrays.sort(prices);
    if(prices[0]+prices[1]>money){
      return money;
    }
    return money-(prices[0]+prices[1]);
  }
  public static void main(String[] args) {
    int prices[]={3,2,3};
    int money=3;
    System.out.println(BuyChoclate(prices, money));
  }
  
}
