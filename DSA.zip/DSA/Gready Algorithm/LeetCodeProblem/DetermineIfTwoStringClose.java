import java.util.Arrays;

public class DetermineIfTwoStringClose {
    public static boolean closeStrings(String word1, String word2) {
        if(word1.length()!=word2.length()){
            return false;
        }
        int word1_freq[]=new int[26]; //calculate word1 char freq
        int word2_freq[]=new int[26]; //calculate word2 char freq

        for(char ch:word1.toCharArray()){
            word1_freq[ch - 'a']++;
        }
        for(char ch:word2.toCharArray()){
              word2_freq[ch - 'a']++;
        }
        //case 1 characterd same
       for(int i=0;i<26;i++){ 
      if(word1_freq[i]==0 && word2_freq[i]!=0 ||//when word 1 have no element and word 2 have elt
         word2_freq[i]==0 && word1_freq[i]!=0 ){//when word 2 have no element and word 1 have elt
           return false; //if this condition occurs return false 
          }

       }
       //case2  same frequncy pattern 
       // word1 = "cabbba", word2 = "abbccc" 
       //word1={a=2:b=3:c=1} word2={a=1:b=2:c=3} -> count diffrent but pattern same 
       Arrays.sort(word1_freq);
       Arrays.sort(word2_freq);
       return Arrays.equals(word1_freq,word2_freq);
    }
    public static void main(String[] args) {
      String word1 = "cabbba", word2 = "abbccc";
      System.out.println(closeStrings(word1,word2));
    }
  
}
