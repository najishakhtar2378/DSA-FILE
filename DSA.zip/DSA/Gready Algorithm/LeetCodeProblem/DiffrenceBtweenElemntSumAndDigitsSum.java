public class DiffrenceBtweenElemntSumAndDigitsSum {
  public static int DiffrenceSum(int nums[]){
    int sum1=0;
    for(int i=0;i<nums.length;i++){
       sum1+=nums[i];
    }
    int sum2=0;
    for(int i:nums){
      int temp=i;
      while(temp>0){
        int rem=temp%10;
        sum2+=rem;
         temp=temp/10;
      }
    }
    return Math.abs(sum1-sum2);
  }
  public static void main(String[] args) {
    int nums[]={1,15,6,3};
    System.out.println(DiffrenceSum(nums));
  }
}
