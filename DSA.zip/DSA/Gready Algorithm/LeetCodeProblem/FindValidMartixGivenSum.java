import java.util.Arrays;

public class FindValidMartixGivenSum {
    public int[][] restoreMatrix(int[] rowSum, int[] colSum){
        int n=rowSum.length;
        int m=colSum.length;
        int res[][]=new int[n][m];
        for(int i=0;i<n;i++){
          for(int j=0;j<m;j++){
            int val=Math.min(rowSum[i],colSum[j]);
            res[i][j]=val;
            //reducing sum 
            rowSum[i]-=val;
            rowSum[j]-=val;
          }
        }
        return res;
    }
    public static void main(String[] args) {
      int rowSum[]={3,8};
      int colSum[]={4,7};
      int ans[][]= restoreMatrix(rowSum,colSum);
      System.out.println(Arrays.toString(ans));
    }
}
