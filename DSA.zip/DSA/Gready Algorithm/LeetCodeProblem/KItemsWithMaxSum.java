
public class KItemsWithMaxSum {
  public static int KItems(int numOnes,int numZeros,int numOnesNeg,int k){
   int sum=0;
   while(k>0){
    if(numOnes>0){
    sum+=1;
    numOnes--;
   }else if(numZeros>0){
    sum+=0;
    numZeros--;
   }else{
    sum+=-1;
    numOnesNeg--;
   }
   k--;
  }
  return sum;
}
public static void main(String[] args) {
  int numOnes=3;
  int numZeros=2;
  int numOnesNeg=0;
  int k=2;
  System.out.println(KItems(numOnes, numZeros, numOnesNeg, k));
}
}
