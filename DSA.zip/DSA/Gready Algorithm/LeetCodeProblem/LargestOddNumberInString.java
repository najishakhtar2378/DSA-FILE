public class LargestOddNumberInString {
  public static String LargestNumber(String num){
    for(int i=num.length()-1;i>=0;i--){
      char ch=num.charAt(i);
      if((ch-'0')%2!=0){
        return num.substring(0, i+1);
      }
    }
    return "";
  }
  public static void main(String[] args) {
    String num="52";
    System.out.println(LargestNumber(num));
  }
}
