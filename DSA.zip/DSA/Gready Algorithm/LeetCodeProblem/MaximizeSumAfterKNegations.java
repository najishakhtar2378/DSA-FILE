import java.util.Arrays;
import java.util.PriorityQueue;

public class MaximizeSumAfterKNegations {
  public static int MaximizeSum(int nums[],int k){
    PriorityQueue<Integer> pq=new PriorityQueue<>();
    Arrays.sort(nums);
    for(int num:nums){
      pq.add(num);
    }
    while(k>0){
      pq.add(-pq.remove()); //jab tk k zero ke equal na ho jaye tb tk pq se ek elemnt ko niklna h use neg bnake add krte rhna h 
      k--;
    }
    int sum=0;
    for(int i=0;i<nums.length;i++){
      sum+=pq.remove(); //all ka sam calculate kr lenge
    }
    return sum;
  }
  public static void main(String[] args) {
    int nums[]={3,-1,0,2};
    System.err.println(MaximizeSum(nums, 3));

  }
  
}
