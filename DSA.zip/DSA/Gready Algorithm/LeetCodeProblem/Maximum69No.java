
public class Maximum69No {
  public static int maximumNo(int num){
    //create stringBuilder
    StringBuilder sb=new StringBuilder();
    sb.append(num);

    for(int i=0;i<sb.length();i++){
      if(sb.charAt(i)=='6'){
        sb.setCharAt(i, '9');
          break;
      }
    }
    return Integer.parseInt(sb.toString());
  }
  public static void main(String[] args) {
    int num=9996;
    System.out.println(maximumNo(num));
  }
}
