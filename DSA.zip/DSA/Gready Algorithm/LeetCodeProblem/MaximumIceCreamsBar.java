import java.util.Arrays;
public class MaximumIceCreamsBar {
  public static int MaximumIceCream(int costs[],int coins){
    int n=costs.length;
    int count=0;
    Arrays.sort(costs);
    for(int i=0;i<n;i++){
      if(costs[i]>coins){
        break;
      }
      coins-=costs[i];
       count++;
    }
    return count;
    }
    public static void main(String[] args) {
      int costs[]={1,2,3,1,4};
      int coins=7;
      System.out.println(MaximumIceCream(costs, coins));

    }
  }
