public class MaximumMatrixSum {
  public static long matrixSum(int matrix[][]){
    long sum=0;
    int negCount=0;
    int minAbs=Integer.MAX_VALUE;
    for(int i=0;i<matrix.length;i++){
      for(int j=0;j<matrix[0].length;j++){
        int val=matrix[i][j];//store i,j val in val
        //find negative count
         if(val<0){
          negCount++;
         }
         minAbs=Math.min(minAbs,Math.abs(val));//find minabs
         sum+=Math.abs(val);
      }
    }
    //if negtiveCount is odd means two adjacnet no exist but 1 is not adjecent to other like -1,-2,-3 here -1 & -2 are adjecent but -3 is not adjecent of any other element or -2 & -3 are adjecnt but -1 is not adjecent of any other element so it odd Negative count reduce total sum-2*minAbs
    if(negCount%2==1){
      sum-=2*minAbs;
    }
    return sum;
  }
  public static void main(String[] args) {
    int matrix[][]={{1,2,3},{-1,-2,-3},{1,2,3}};
    System.out.println(matrixSum(matrix));
  }
  
}
