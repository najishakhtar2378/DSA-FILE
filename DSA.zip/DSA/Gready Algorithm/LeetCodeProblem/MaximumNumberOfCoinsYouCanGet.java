import java.util.Arrays;

public class MaximumNumberOfCoinsYouCanGet {
  public static int maxCoinYouGet(int piles[]){
    int n=piles.length;
    int res=0;
    Arrays.sort(piles);
    for(int i=n-2;i>=n/3;i-=2){
      res+=piles[i];

    }
    return res;
  }
  public static void main(String[] args) {
    int piles[]={9,8,7,6,5,4,3,2,1};
    System.out.println(maxCoinYouGet(piles));
  }
  
}
