
public class MaximumNumberOfOprationToMovesAtEnd {
  public static int Maxoprn(String s){
    int n=s.length();
    int ones=0;
    int countOpn=0;
    for(int i=0;i<n;i++){
      if(s.charAt(i)=='1'){
        ones++;
      }else if(i>0 && s.charAt(i-1)=='1'){//check prev is one or not if prev is 1 exist then opration will be perform
        countOpn+=ones;
      }
  }
  return countOpn;
}
public static void main(String[] args) {
  String s="1001101";
  System.out.println(Maxoprn(s));
}
}