public class MaximumOddBinaryNumber {
  public static String MaximumOdd(String s){
    int ones=0;
    for(char ch:s.toCharArray()){
      if(ch=='1'){
        ones++; //count '1'
      }
    }
      int zeros=s.length()-ones;//count zeros
      StringBuilder sb=new StringBuilder();
      for(int i=0;i<ones-1;i++){ //max ones starting at 1st position
          sb.append('1');
      }
      for(int j=0;j<zeros;j++){
        sb.append('0'); //zero filled after 1
      }
      sb.append('1'); // add 1 at last positions
      return sb.toString();
  }
  public static void main(String[] args) {
    String s="0101";
    System.out.println(MaximumOdd(s));
  }
  
}
