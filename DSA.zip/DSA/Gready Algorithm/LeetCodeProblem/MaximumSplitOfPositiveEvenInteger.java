import java.util.ArrayList;
import java.util.List;

public class MaximumSplitOfPositiveEvenInteger {
  public static List<Long> MaximumSplit(long finalSum){
    List<Long>ls=new ArrayList<>();
    if(finalSum%2==1){ //when final Sum is odd
      return ls;
    }
    long sum=finalSum;
    long temp=2;
    while(temp<=sum){
      ls.add(temp);
      sum-=temp;
      temp+=2; //temp increse by 2 bcz we makes even Integer
    }
    ls.add(ls.remove(ls.size()-1)+sum); //when finalSum not split then last element remove the ls and add remaining sum again add ls
    return ls;
  }
  public static void main(String[] args) {
    long finalSum=28;
    System.out.println(MaximumSplit(finalSum));
     
  }
}
