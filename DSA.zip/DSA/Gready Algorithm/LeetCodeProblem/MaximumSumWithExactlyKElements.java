
public class MaximumSumWithExactlyKElements {
  public static int MaximumSum(int nums[],int k){
  int max=0;
 for(int num:nums){
  max=Math.max(max,num);
}
  int sum=max;//max element foud then make its sum
   while(k>1){
    max++; //har sum ke baad max ko +1 se increase krenge or phir usko add krenge 
    sum+=max;
    k--;
   }
   return sum;
}
public static void main(String[] args) {
 int nums[]={1,2,3,4,5};
 System.out.println(MaximumSum(nums, 3)); 
}
}