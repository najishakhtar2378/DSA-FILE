
public class MaximumSumWithExactlyKElt {
  public static int maximumSum(int nums[],int k){
    int max=0;
    for(int num:nums){
      max=Math.max(max,num);
      int sum=max;
      while(k>1){
        max++;
        sum+=max;
        k--;
      }
    }
    return max;
  }
  public static void main(String[] args) {
    int nums[]={1,2,3,4,5};
    int k=3;
    System.out.println(maximumSum(nums, k));
  }
  
}
