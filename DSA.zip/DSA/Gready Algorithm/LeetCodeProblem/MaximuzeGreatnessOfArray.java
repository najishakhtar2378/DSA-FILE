import java.util.Arrays;

public class MaximuzeGreatnessOfArray {
  public static int GreatnessArr(int nums[]){
    int n=nums.length;
    int i=0;
    int j=1;
    int count=0;
    Arrays.sort(nums);
    while(j<n){
      if(nums[i]==nums[j]){
        j++;
      }else if(nums[i]<nums[j]){
        count++;
        i++;
        j++;
      }
    }
    return count;

  }
  public static void main(String[] args) {
    int nums[]={1,3,5,2,1,3,1};
    System.out.println(GreatnessArr(nums));
  }
  
}
