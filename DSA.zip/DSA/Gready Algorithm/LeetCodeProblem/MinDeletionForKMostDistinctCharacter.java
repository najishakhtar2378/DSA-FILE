import java.util.Arrays;

public class MinDeletionForKMostDistinctCharacter {
   public static int minDeletion(String s, int k) {
        int count[]=new int[26];
        for(char ch:s.toCharArray()){
            count[ch-'a']++; //calculate the freq of char 
        }
        Arrays.sort(count);
        int res=0;
        for(int i=0;i<26-k;i++){
            res+=count[i];
        }
        return res;
    }
    public static void main(String[] args) {
      String s="aabb";
       int k=2;
      System.out.println(minDeletion(s,k));
    }
}
  

