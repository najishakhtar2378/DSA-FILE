import java.util.Arrays;
public class MinIncrementToMakeArrayUnique {
  public static int minIncrementArr(int nums[]){
    return minOpration(nums);
  }
  public static int minOpration(int nums[]){
    Arrays.sort(nums);
    int count=0;
    int max=nums[0];
    for(int i=1;i<nums.length;i++){
      if(nums[i]>max){
        max=nums[i];
      }else{
        max++;
        count+=max-nums[i];
      }
    }
    return count;
  }
  public static void main(String[] args) {
    int nums[]={3,2,1,2,1,7};
    System.out.println(minOpration(nums));
  }
}
