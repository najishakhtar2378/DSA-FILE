
public class MinMovesToConvertString {
  public static int minMoves(String s){
    int i=0;
    int moves=0;
    while(i<s.length()){
      if(s.charAt(i)=='X'){
         i=i+3;
         moves++;
      }else{
        i++; //when s.charAt(i)!=0;
      }
    }
    return moves;
  }
  public static void main(String[] args) {
    // String s="XXX";
    String s= "XOXX";
    System.out.println(minMoves(s));
  }
  
}
