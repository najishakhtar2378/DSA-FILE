import java.util.HashSet;
import java.util.Set;

public class MinNoOfOprationToMakeElementInArrayDistinct {
  public static int minOpration(int nums[]){
    int n=nums.length;
    Set<Integer> st=new HashSet<>();
    for(int i=n-1;i>=0;i--){
      if(st.contains(nums[i])){
        return (int)Math.ceil((i+1)/3.0);
      }
      st.add(nums[i]);
    }
    return 0;
  }
  public static void main(String[] args) {
    int nums[]={1,2,3,4,2,3,3,5,7};
     System.out.println(minOpration(nums));
  }
}
