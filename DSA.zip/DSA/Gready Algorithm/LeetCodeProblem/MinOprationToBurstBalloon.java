import java.util.Arrays;
import java.util.Comparator;

public class MinOprationToBurstBalloon {
  public static int MinOprationBurst(int points[][]){
     int n=points.length;
     Arrays.sort(points,Comparator.comparingInt(a->a[0]));
     int prev[]=points[0];
     int count=1;
     for(int i=1;i<n;i++){
      int currStPoints=points[i][0];
      int currEndPoints=points[i][1];
      int prevStPoint=prev[0];
      int prevEndPoints=prev[1];
      //no overlappig case [1,6][2,8]
      if(currStPoints>prevEndPoints){
         count++;
         prev=points[i];
      }else{   //overlaping case
        prev[0]=Math.max(prevStPoint,currStPoints);
        prev[1]=Math.min(prevEndPoints,currEndPoints);

      }
     }
     return count;
  }
  public static void main(String[] args) {
    int points[][]={{1,6},{2,8},{7,12},{10,16}};
    System.out.println(MinOprationBurst(points));
  }

}
