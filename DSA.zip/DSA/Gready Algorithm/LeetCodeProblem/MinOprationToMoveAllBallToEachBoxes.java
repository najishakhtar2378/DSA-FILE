import java.util.Arrays;
import java.util.HashSet;

public class MinOprationToMoveAllBallToEachBoxes {
  public static int[] minOpration(String boxes){
    int n=boxes.length();
    HashSet<Integer> hs =new HashSet<>();
     for(int i=0;i<n;i++){
      if(boxes.charAt(i)=='1'){
        hs.add(i);
      }
     }
     int res[]=new int[n];
     for(int i=0;i<n;i++){
      for(int idx:hs){
        res[i]+=Math.abs(i-idx);
      }
     }
     return res;
  }
  public static void main(String[] args) {
    String boxes="110";
    int ans[]=minOpration(boxes);
    System.out.println(Arrays.toString(ans));
  }
}
