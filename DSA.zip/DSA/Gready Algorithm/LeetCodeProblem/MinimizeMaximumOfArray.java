public class MinimizeMaximumOfArray {
  public static int maximumArray(int nums[]){
    long sum=0;
    long MinMax=0;
    for(int i=0;i<nums.length;i++){
      sum+=nums[i]; //find prefix sum
      MinMax=Math.max((sum+i)/(i+1),MinMax); //find average of prefix sum
    }
    return (int)MinMax;
  }
  public static void main(String[] args) {
    int nums[]={3,7,1,6};
    System.out.println(maximumArray(nums));
  }
}
