import java.util.Arrays;

public class MinimizeMaximumPairSum {
  public static int MaxPairSum(int nums[]){
    Arrays.sort(nums);
    int sum=0;
    int maxSum=0;
    int i=0;
    int j=nums.length-1;
    while(i<j){
      sum=nums[i]+nums[j];
      maxSum=Math.max(maxSum,sum);
      i++;
      j--;
    }
    return maxSum;
  }
  public static void main(String[] args) {
    int nums[]={3,5,2,3};
    System.out.println(MaxPairSum(nums));
  }
  
}
