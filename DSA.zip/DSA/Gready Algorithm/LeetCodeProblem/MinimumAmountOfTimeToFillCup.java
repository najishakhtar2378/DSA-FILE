import java.util.Arrays;

public class MinimumAmountOfTimeToFillCup {
  public static int MinAmount(int amount[]){
    Arrays.sort(amount);
    int totSum=amount[0]+amount[1]+amount[2];
    return Math.max((totSum+1)/2,amount[2]);//where amount[2] is maximum amount of cups isko alg se bhrne ke liye v time lgega isiliye iska time or pair me jitna time lga h uska maximum krenge tb jake total time pta chalge 
  }
  public static void main(String[] args) {
    int amount[]={4,4,5};
    System.out.println(MinAmount(amount));
  }
}
