
public class MinimumCostToMoveChipsSamePosition {
  public static int MinCostToMoveChips(int positions[]){
     int n=positions.length;
     int even=0;
     int odd=0;
     for(int x:positions){
        if(x%2==0){
          even++;
        }else{
          odd++;
        }
     }
     return Math.min(even,odd);
  }
  public static void main(String[] args) {
    int positions[]={2,2,2,3,3};
    System.out.println(MinCostToMoveChips(positions));
  }
  
}
