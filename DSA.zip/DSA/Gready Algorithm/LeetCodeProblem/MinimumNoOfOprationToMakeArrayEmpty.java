
import java.util.HashMap;

public class MinimumNoOfOprationToMakeArrayEmpty {
  public static int minOpr(int nums[]){
    int oprn=0;
    HashMap<Integer,Integer> hm = new HashMap<>(); 

    for(int num:nums){
      hm.put(num,hm.getOrDefault(num,0)+1);//fin the total frequency of each element
    }
  for(int countFreq: hm.values()){
    if(countFreq==1)
       return -1;
      else if(countFreq%3==0)
        oprn+=countFreq/3;
      else if(countFreq%3==1)
       oprn+=(countFreq/3 -1)+2;
       else
       oprn+=countFreq/3+1;
     }
     return oprn;
  }
  public static void main(String[] args) {
    int nums[]={2,3,3,2,2,4,2,3,4};
    System.out.println(minOpr(nums));
  }
}