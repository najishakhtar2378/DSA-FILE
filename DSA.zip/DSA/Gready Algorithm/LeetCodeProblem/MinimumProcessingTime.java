import java.util.ArrayList;
import java.util.Collections;

public class MinimumProcessingTime {
  public static int MinimumProsTime(ArrayList<Integer> processingTime,ArrayList<Integer> tasks){
    Collections.sort(tasks);
    Collections.sort(processingTime,Collections.reverseOrder());
    int ans=Integer.MIN_VALUE;
    int k=0; //handle tasks value
    for(int i=0;i<processingTime.size();i++){
      for(int j=1;j<=4;j++){ //handle 4 processingTime
        ans=Math.max(ans,processingTime.get(i)+tasks.get(k));
        k++;
      }
    }
    return ans;
    
  }
  public static void main(String[] args) {
    ArrayList<Integer> pos=new ArrayList<>();
    pos.add(8);
    pos.add(10);
    ArrayList<Integer> tas=new ArrayList<>();
    tas.add(2);
    tas.add(2);
    tas.add(3);
    tas.add(1);
    tas.add(8);
    tas.add(7);
    tas.add(4);
    tas.add(5);
    System.out.println(MinimumProsTime(pos, tas));
  }
  
}
