public class MinimumSwaptoEqualString {
  public static int MinSwap(String s1,String s2){
    int Count_X=0,Count_y=0;
    for(int i=0;i<s1.length();i++){
      if(s1.charAt(i)!=s2.charAt(i)){
          if(s1.charAt(i)=='x'){
            Count_X++;
          }else{
            Count_y++;
          }
      }
    }
    // check the value of Odd or event Count_X and Count_Y
    if(Count_X%2==0 && Count_y%2==0){
      return (Count_X+Count_y)/2;
    }
    if(Count_X%2==1 && Count_y%2==1){
      return (Count_X+Count_y)/2+1;
    }
    return -1;
  }
  public static void main(String[] args) {
    String s1="xx";
    String s2="yy";
    //swap x<->y then s1 becomes xy and s2 becomes xy
    System.out.println(MinSwap(s1, s2));
  }
}
