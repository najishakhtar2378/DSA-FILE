import java.util.Arrays;

public class SeprateTheDigitInArr {
  public static int[] SeprateDigit(int nums[]){
    StringBuilder sb=new StringBuilder();
    for(int num:nums){
      sb.append(num);
    }
    String str=sb.toString();//sb conerts to normal String
    int res[]=new int[str.length()];
    for(int i=0;i<str.length();i++){
       res[i]=str.charAt(i)-'0';
    }
    return res;
  }
  public static void main(String[] args) {
    int nums[]={13,25,83,77};
    int ans[]=SeprateDigit(nums);
    System.out.println(Arrays.toString(ans));
  }
  
}
