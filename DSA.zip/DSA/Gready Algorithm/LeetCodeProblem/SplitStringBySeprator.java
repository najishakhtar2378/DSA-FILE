import java.util.ArrayList;
import java.util.List;

public class SplitStringBySeprator {
   public static List<String> splitWord(List<String> words, char separator){
    List<String> ls=new ArrayList<>();
     for(String word: words){
      String temp[]=word.split("["+separator+"]");
      for(String s:temp){
        if(s.length()>=1){
          ls.add(s);
        }
      }
     }
     return ls;
    }
    public static void main(String[] args) {
      // String words="one.two.three","four.five","six";
    }
}
