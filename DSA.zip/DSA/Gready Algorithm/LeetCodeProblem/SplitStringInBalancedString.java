
public class SplitStringInBalancedString {
  public static int BalancedString(String s){
    int countL=0,countR=0; 
    int count=0;
    for(int i=0;i<s.length();i++){
      if(s.charAt(i)=='L'){
        countL++;
      }else{
        countR++;
      }
     if(countL==countR){
      count++;
     }
    }
    return count;
  }
  public static void main(String[] args) {
    String s="RLRRLLRLRL";
    System.out.println(BalancedString(s));
  }
  
}
