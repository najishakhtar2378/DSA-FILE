import java.util.ArrayList;
import java.util.Collections;

public class SplitWithMinimumSum {
  public static int SplitWithMinSum(int num){
    ArrayList<Integer> ls=new ArrayList<>();
    while(num>0){
      ls.add(num%10);
       num=num/10;
    }
    Collections.sort(ls);
      int n1=0,n2=0; //where n1 and n2 is num1 and num2 
    for(int i=0;i<ls.size();i++){
      if(i%2==0){
        n1=n1*10+ls.get(i);
        }else{
            n2=n2*10+ls.get(i);
         }
       }
       return n1+n2;
    }
     public static void main(String[] args) {
      int num= 4235;
      System.out.println(SplitWithMinSum(num));
     }
  }
