import java.util.Arrays;

public class TwoCitySceduling {
  public static int CitySceduling(int [][] costs){
    Arrays.sort(costs,(a,b)->(a[0]-a[1] -(b[0]-b[1])));
    int n=costs.length/2;
    int ans=0;
    for(int i=0;i<n;i++){
      ans+=costs[i][0]; //city A
    }
    for(int i=n;i<2*n;i++){
      ans+=costs[i][1]; //city B
    }
    return ans;
  }
  public static void main(String[] args) {
    int costs[][]={{10,20},{30,200},{400,50},{30,20}};
    System.out.println(CitySceduling(costs));
  
}
}