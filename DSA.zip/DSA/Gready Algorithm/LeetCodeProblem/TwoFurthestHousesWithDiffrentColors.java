public class TwoFurthestHousesWithDiffrentColors {
  public static int DiffColors(int colors[]){
    int ans=0;
    int n=colors.length;
    // compare first colors with others
    for(int i=1;i<n;i++){
      if(colors[i]!=colors[0]){
        ans=Math.max(ans,i);
      }
    }
    //compare last with others
    for(int i=0;i<n-1;i++){
      if(colors[i]!=colors[n-1]){
        ans=Math.max(ans,i);
      }
    }
    return ans;
  }
  public static void main(String[] args) {
    int colors[]={1,1,1,6,1,1,1};
    System.out.println(DiffColors(colors));
  }
}
