public class findMinFibonacciNumbers {
  public static int FindMinFib(int k){
    //base case 
    if(k<=1){
      return k;
    }
    //find fibonacci
    int a=1,b=1,c=2;
    while(c<=k){
      a=b;
      b=c;
      c=a+b;
    }
   return 1+FindMinFib(k-b);
  }
  public static void main(String[] args) {
    int k=7;
    System.out.println(FindMinFib(k));
  }
}
