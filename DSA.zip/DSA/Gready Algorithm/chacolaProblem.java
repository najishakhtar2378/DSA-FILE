import java.util.Arrays;
import java.util.Collections;

public class chacolaProblem {
    public static void main(String[] args) {
        int n=4,m=6;
        Integer costVar[]={7,3,2,4,9,12,56};
        Integer costHor[]={3,2,4};

        // sorting
        Arrays.sort(costVar,Collections.reverseOrder());
        Arrays.sort(costHor,Collections.reverseOrder());
        int h=0,v=0;
        // hp and vp are horiz peice and vert piece
        int hp=1,vp=1;
        int cost=0;
        while(h<costHor.length&&v<costVar.length){
            if(costVar[v]<=costHor[h]){
                cost+=(costHor[h]*vp);
                hp++;
                h++;
                }else{
                    cost+=(costVar[v]*hp);
                    vp++;
                    v++;
                }
            }
            while(h<costHor.length){
                cost+=(costHor[h]*vp);
                hp++;
                h++;
            }
            while(v<costVar.length){
                cost+=(costVar[v]*hp);
                vp++;
                v++;
            }
            System.out.println("min cost of cuts="+cost);

        }
    }
    

