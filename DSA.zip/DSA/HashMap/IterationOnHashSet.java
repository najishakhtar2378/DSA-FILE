import java.util.HashSet;
public class IterationOnHashSet {
  public static void main(String[] args) {
    HashSet<String> cities =new HashSet<>();
    cities.add("mumbai");
    cities.add("delhi");
    cities.add("Noida");
    cities.add("Benguluru");
    // using iterator
    // Iterator it=cities.iterator();
    // while(it.hasNext()){
    //   System.out.println(it.next());
    // }
    // using for EachLoop/advanced for loop
    for(String city:cities){
      System.out.println(city);
    }
  }
}
