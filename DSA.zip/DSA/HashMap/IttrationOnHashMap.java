import java.util.HashMap;
import java.util.Set;
public class IttrationOnHashMap {
  public static void main(String[] args) {
    HashMap<String,Integer>hm=new HashMap<>();
    hm.put("india", 100);
    hm.put("chaina", 150);
    hm.put("US", 50);
    hm.put("Indonessia", 6);
    hm.put("Nepal", 5);
    // ittraton
    Set<String>keys=hm.keySet();
    System.out.println(keys);
    for (String k: keys) {
      System.out.println("keys="+k+",values="+hm.get(k));
      
    }
    
  }
  
}
