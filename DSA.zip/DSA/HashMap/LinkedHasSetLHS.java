import java.util.HashSet;
import java.util.LinkedHashSet;
public class LinkedHasSetLHS {
    public static void main(String[] args) {
    HashSet<String>cities=new HashSet<>();
    cities.add("delhi");
    cities.add("mumbai");
    cities.add("Noida");
    cities.add("Bengluru");
    System.out.println(cities);

    LinkedHashSet<String>lhs=new LinkedHashSet<>();
    lhs.add("delhi");
    lhs.add("mumbai");
    lhs.add("Noida");
    System.out.println(lhs);
    
  }
  
}
  
