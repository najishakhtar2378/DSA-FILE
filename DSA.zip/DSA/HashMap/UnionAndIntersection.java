import java.util.HashSet;
public class UnionAndIntersection {
  public static void main(String[] args) {
    int arr1[]={7,3,9};
    int arr2[]={9,3,9,6,2,4};
    HashSet<Integer>Set=new HashSet<>();
    for(int i=0;i<arr1.length;i++){
      Set.add(arr1[i]);
    }
    for(int i=0;i<arr2.length;i++){
      Set.add(arr2[i]);
    }

    System.out.println("Union="+Set.size());

    // union element
    // for(int i=0;i<Set.size();i++){
    //   System.out.println(Set);
    // }

    // intersection
    Set.clear();
    for(int i=0;i<arr1.length;i++){
      Set.add(arr1[i]);
    }
    int count=0;
    for(int i=0;i<arr2.length;i++){
      if(Set.contains(arr2[i])){
        count++;
        Set.remove(arr2[i]);

      }
    }
    System.out.println("Intersection="+count);
  }
  
}
