
import java.util.ArrayList;
import java.util.HashMap;
public class SortCharacter {
  public static String FrequncySort(String s){
    StringBuilder answer=new StringBuilder();
    HashMap<Character,Integer> hm=new HashMap<>();
    for(char ch: s.toCharArray()){
      hm.put(ch, hm.getOrDefault(ch,0)+1);
    }
   ArrayList<Character> list=new ArrayList(hm.keySet());
   list.sort((ob1,ob2) -> hm.get(ob2)-hm.get(ob1));
   for(char ch:list){
    for(int i=0;i<hm.get(ch);i++){ 
      answer.append(ch);
      System.out.print(ch);
    }
   }
   return answer.toString();
  }
  public static void main(String[] args) {
    String s="fffccc";
    FrequncySort(s);

  }
}
