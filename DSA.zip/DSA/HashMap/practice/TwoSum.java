import java.util.HashMap;
public class TwoSum {
  public static int[] twosum(int arr[],int target){
    HashMap<Integer,Integer> set= new HashMap<>();
    for(int i=0;i<arr.length;i++){
      int ar=arr[i];
      int rem=target-ar;
      if(set.containsKey(rem)){
        return new int[]{i,set.get(rem)};
      }
      set.put(ar,i); 
    }
    return new int[]{};
  }
  public static void main(String[] args) {
    int arr[]={2,8,7,15};
    // int arr[]={3,2,4};
    int target=22;
    twosum(arr, target);
   

  }
  
}
