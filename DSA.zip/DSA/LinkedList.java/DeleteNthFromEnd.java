public class DeleteNthFromEnd {
  public static class node {
    int data;
    node next;

    // cunstructor
    public node(int data) {
      this.data = data;
      this.next = null;
    }
  }

  public static node head;
  public static node tail;
  public static int size;
  
  public void addFirst(int data) {
    // step 1st ---> create new node
    node newNode = new node(data);
    if (head == null) {
      head = tail = newNode;
      return;
    }
    // step 2nd----> newNode next=head
    newNode.next = head;
    // link

    // step 3----> head=new nodes
    head = newNode;
  }

  // for fx addLast
  public void addLast(int data) {
    node newNode = new node(data);
    if (head == null) {
      head = tail = newNode;
      return;
    }
    tail.next = newNode;
    tail = newNode;
  }

  public void print() {
    node temp = head;
    while (temp != null) {
      System.out.print(temp.data + "-->");
      temp = temp.next;
    }
    System.out.println("null");
  }
  public static void deleteNthfromEnd(int n){
    // calculate size
    int size=0;
    node temp=head;
    while(temp!=null){
      temp=temp.next;
      size++;
    }
    // when delete head node 
    if(n==size){
      head=head.next;
      return;
    }
    // link before the delete node and after the delete node  
    int i=1;
    int itoFind=size-n;
    node prev=head;
    while(i<itoFind){
      prev=prev.next;
      i++;
    }
    prev.next=prev.next.next;
    return;
  }
  public static void main(String[] args) {
    DeleteNthFromEnd ll=new DeleteNthFromEnd();
    ll.print();
    ll.addFirst(2); 
    ll.print();
    ll.addFirst(1);
    ll.print();
    ll.addLast(3);
    ll.print();
    ll.addLast(4);
    ll.print();
    ll.addLast(5); 
    ll.deleteNthfromEnd(3);
    ll.print();
  }
  
}