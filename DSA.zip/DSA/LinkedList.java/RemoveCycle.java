
public class RemoveCycle {
    public static class node{
        int data;
        node next;
        // cunstructor
        public node(int data){
            this.data=data;
            this.next=null;
        }
    }
        public static node head;
        public static node tail; 
        public static boolean isCycle() {
          node slow = head;
          node fast = head;
          while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
              return true; // cycle exist
            }
          }
          return false; // cycle does not exist
        }
        public static void removeCycle(){
          node slow=head;
          node fast=head;
          boolean cycle=true;
          while(fast!=null && fast.next!=null){
            slow = slow.next;
            fast=fast.next.next;
          
          if(fast==slow){
            cycle=true;
            break;
        }
      }
      if(cycle==false){
        return;
      }
      // find meating point
      slow= head;
      node prev=null;
      if(slow!=fast){
        prev=fast;
        slow=slow.next;
        fast=fast.next;
      }
      prev.next=null;  //last node =prev
}
public static void main(String[] args) {
  head=new node(1);
  node temp=new node(2);
  head.next=temp;
  head.next.next=new node(3);
  head.next.next=temp;
  System.out.println(isCycle());
  removeCycle();
  System.out.println(isCycle());

  
}
}