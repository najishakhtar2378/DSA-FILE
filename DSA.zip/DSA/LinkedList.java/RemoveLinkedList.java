public class RemoveLinkedList {
  public static class node {
    int data;
    node next;
    // cunstructor
    public node(int data) {
      this.data = data;
      this.next = null;
    }
  }
  public static node head;
  public static node tail;
  public static int size;
  
  public void addFirst(int data) {
    // step 1st ---> create new node
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    // step 2nd----> newNode next=head
    newNode.next = head;
    // link

    // step 3----> head=new nodes
    head = newNode;
  }

  // for fx addLast
  public void addLast(int data) {
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    tail.next = newNode;
    tail = newNode;
  }

  public void print() {
    node temp = head;
    while (temp != null) {
      System.out.print(temp.data + "-->");
      temp = temp.next;
    }
    System.out.println("null");
  }
  //remove first
  public int removefirst(){
    // case 1
    if(size==0){
      System.out.println("ll is empty");
      return Integer.MIN_VALUE;
      // case 2
    }else if(size==1){
      int val=head.data;
      head=tail=null;
      return val;
    }
    int val=head.data;
    head=head.next;
    return val;
  }

  public int removelast() {
    if (size == 0) {
      System.out.println("ll is empty");
      return Integer.MIN_VALUE;
    } else if (size == 1) {
      int val = head.data;
      head = tail = null;
      size = 0;
      return val;
    }
    // prev= i= size-2
    node prev = head;
    for (int i=0; i<size-2; i++) {
      prev = prev.next;
    }
    int val=prev.next.data;
    prev.next = null;  
    tail=prev;
    size--;
    return val;
  }
  public static void main(String[] args) {
    RemoveLinkedList  ll =new RemoveLinkedList();
    ll.print();
    ll.addFirst(2);
    ll.print();
    ll.addFirst(1);
    ll.print();
    ll.addLast(3);
    ll.print();
    ll.addLast(4);
    ll.print();
    ll.addLast(5);

  // ll.removefirst();
  // ll.print();

  ll.removelast();
  ll.print();
    
  }
  
}
