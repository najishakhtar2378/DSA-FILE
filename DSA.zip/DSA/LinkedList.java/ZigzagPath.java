public class ZigzagPath {
  public static class node {
    int data;
    node next;

    // cunstructor
    public node(int data) {
      this.data = data;
      this.next = null;
    }
  }
  public static node head;
  public static node tail;
  public static int size;
  
  public void addFirst(int data) {
    // step 1st ---> create new node
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    // step 2nd----> newNode next=head
    newNode.next = head;
    // link

    // step 3----> head=new nodes
    head = newNode;
  }

  // for fx addLast
  public void addLast(int data) {
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    tail.next = newNode;
    tail = newNode;
  }

  public void print() {
    node temp = head;
    while (temp != null) {
      System.out.print(temp.data + "-->");
      temp = temp.next;
    }
    System.out.println("null");
  }
  public void zigZag() {
    // find mid
    node slow = head;
    node fast = head.next;
    while (fast != null && fast.next != null) {
      slow = slow.next;
      fast = fast.next.next;
    }
    node mid = slow;
    // reverse 2nd half
    node curr = mid.next;
    mid.next = null;
    node prev = null;
    node next;
    while (curr != null) {
      next = curr.next;
      curr.next = prev;
      prev = curr;
      curr = next;
    }
    node left = head;
    node right = prev;
    node nextL, nextR;
    // alt merge-- zig zag merge
    while (left != null && right != null) {
      nextL = left.next;
      left.next = right;
      nextR = right.next;
      right.next = nextL;
      left = nextL;
      right = nextR;
    }
  }
  public static void main(String[] args) {
    ZigzagPath ll=new ZigzagPath();
    ll.print();
    ll.addFirst(2);
    ll.print();
    ll.addFirst(1);
    ll.print();
    ll.addLast(3);
    ll.print();
    ll.addLast(4);
    ll.print();
    ll.addLast(5);
    // System.out.println(ll.zigZag());
    ll.zigZag();
  }
  
}
