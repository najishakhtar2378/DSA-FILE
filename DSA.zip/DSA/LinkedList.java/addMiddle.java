public class addMiddle {
  public static class node {
    int data;
    node next;

    // cunstructor
    public node(int data) {
      this.data = data;
      this.next = null;
    }
  }

  public static node head;
  public static node tail;
  public static int size;
  
  public void addFirst(int data) {
    // step 1st ---> create new node
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    // step 2nd----> newNode next=head
    newNode.next = head;
    // link

    // step 3----> head=new nodes
    head = newNode;
  }

  // for fx addLast
  public void addLast(int data) {
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    tail.next = newNode;
    tail = newNode;
  }

  public void print() {
    node temp = head;
    while (temp != null) {
      System.out.print(temp.data + "-->");
      temp = temp.next;
    }
    System.out.println("null");
  }
 
  public void add(int idx, int data) {
    // insert data at head 
    if (idx == 0) {
      addFirst(data);
      return;
    }
    node newNode = new node(data);
    size++;
    node temp = head;
    int i = 0;
    while (i < idx - 1) {
      temp = temp.next;
      i++;
    }
    // i=idx-1;temp-->previus
    // 1->2->9->3->4->null
    newNode.next = temp.next;
    // 2->9->3
    temp.next = newNode;
  }
  public static void main(String[] args) {
    
  
  addMiddle ll = new addMiddle();
  ll.print();
  ll.addFirst(2);
  ll.print();
  ll.addFirst(1);
  ll.print();
  ll.addLast(3);
  ll.print();
  ll.addLast(4);
  ll.print();
  ll.addLast(5);

  // insert data in ll

  ll.add(2 ,9);
  ll.print();
  System.out.println(ll.size);
  
}
}
