public class addRemove {
  public static class node {
    int data;
    node next;

    // cunstructor
    public node(int data) {
      this.data = data;
      this.next = null;
    }
  }

  public static node head;
  public static node tail;

  // find the size of linklist
  public static int size;

  // for fx addFirst
  public void addFirst(int data) {
    // step 1st ---> create new node
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    // step 2nd----> newNode next=head
    newNode.next = head;
    // link
    // step 3----> head=new nodes
    head = newNode;
  }
  // for fx addLast
  public void addLast(int data) {
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    tail.next = newNode;
    tail = newNode;
  }

  public void print() {
    node temp = head;
    while (temp != null) {
      System.out.print(temp.data + "-->");
      temp = temp.next;
    }
    System.out.println("null");
  }
  public static void main(String[] args) {
    addRemove ll = new addRemove();
    ll.print();
    ll.addFirst(2);
    ll.print();
    ll.addFirst(1);
    ll.print();
    ll.addLast(3);
    ll.print();
    ll.addLast(4);
    ll.print();
    ll.addLast(5);
  }
  
}
