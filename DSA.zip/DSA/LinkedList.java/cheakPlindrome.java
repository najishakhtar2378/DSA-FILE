public class cheakPlindrome {
  public static class node {
    int data;
    node next;

    // cunstructor
    public node(int data) {
      this.data = data;
      this.next = null;
    }
  }

  public static node head;
  public static node tail;
  
  // public void addFirst(int data) {
  //   // step 1st ---> create new node
  //   node newNode = new node(data);
  //   if (head == null) {
  //     head = tail = newNode;
  //     return;
  //   }
  //   // step 2nd----> newNode next=head
  //   newNode.next = head;
  //   // link

  //   // step 3----> head=new nodes
  //   head = newNode;
  // }

  // for fx addLast
  public void addLast(int data) {
    node newNode = new node(data);
    if (head == null) {
      head = tail = newNode;
      return;
    }
    tail.next = newNode;
    tail = newNode;
  }

  public void print() {
    node temp = head;
    while (temp != null) {
      System.out.print(temp.data + "-->");
      temp = temp.next;
    }
    System.out.println("null");
  }
  // find mid in palindromic linkedlist
  public node findMid(node head){
    node slow=head;
    node fast=head;
    while(fast!=null&&fast.next!=null){
      slow=slow.next;
      fast=fast.next.next;
    }
    return slow;
  }
  public boolean cheakPlindrome(){
    if(head==null||head.next==null){
      return true;
    }
    node midfind=findMid(head);

    // half reverse
    node prev=null;
    node curr=midfind;
    node next;
    if(curr!=null){
      next=curr.next;
      curr.next=prev;
      prev=curr;
      curr=next;
    }
    node right=prev;
    node left=head;

    // cheak lefthalf is equal to righthalf
    while(right!=null){
      if(left.data!=right.data){
        return false;
      }
    }
    return true;
  }

  public static void main(String[] args) {
   cheakPlindrome ll=new cheakPlindrome();
    ll.addLast(1);
    ll.addLast(2);
    ll.addLast(2);
    ll.addLast(1);
    ll.print();
    // System.out.println(ll.cheakPlindrom());
    // System.out.println(ll.cheakplindrome());
    System.out.println(ll.cheakPlindrome());
  }
  
}
