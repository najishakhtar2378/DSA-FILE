public class cyclicLinkList {
    public static class node{
        int data;
        node next;
        // cunstructor
        public node(int data){
            this.data=data;
            this.next=null;
        }
    }
        public static node head;
        public static node tail;
        public static boolean isCycle(){
            node slow=head;
            node fast=head;
            while(fast!=null && fast.next!=null){
                slow =slow.next;
                fast=fast.next.next;
                if(slow==fast){
                    return true; // cycle exist
                }
            }
            return false; // cycle does not exist
            
        }
        // Remove a cycle in linked list
        // cycle detect condition
        public static void removeCycle(){
            node slow=head;
            node fast=head;
            boolean cycle=false;
            while(fast!=null&&fast.next!=null){
                slow=slow.next;
                fast=fast.next.next;
                if(fast==slow){
                    cycle=true;
                    break;
                }

            }
            if(cycle==false){
                return;
            }
            // find meating point
            slow=head;
            node prev=null;
            while(slow!=fast){
                prev=fast;
                slow=slow.next;
                fast=fast.next;
            }
            // remove cycle --> last.next--->null
            prev.next=null;
        }
        public static void main(String[] args) {
            head=new node(1);
            head.next=new node(2);
            head.next.next=new node(3);
            head.next.next.next=head;
            System.out.println(isCycle());
        

            // remove a cycle in linklist
            // head=new node(1);
            // node temp=new node(2);
            // head.next=temp;
            // head.next.next=new node(3);
            // head.next.next.next=temp;
            // System.out.println(isCyclic());
            // removeCycle();
            // System.out.println(isCyclic());
        }
    
}
