public class mergeshortLL {
    public static class node{
        int data;
        node next;
        // cunstructor
        public node(int data){
            this.data=data;
            this.next=null;
        }
    }
        public static node head;
        public static node tail;
        public static int size;
        
        public void addFirst(int data) {
            // step 1st ---> create new node
            node newNode = new node(data);
            size++;
            if (head == null) {
                head = tail = newNode;
                return;
            }
            // step 2nd----> newNode next=head
            newNode.next = head;
            // link

            // step 3----> head=new nodes
            head = newNode;
        }

        // for fx addLast
        public void addLast(int data) {
            node newNode = new node(data);
            size++;
            if (head == null) {
                head = tail = newNode;
                return;
            }
            tail.next = newNode;
            tail = newNode;
        }

        public void print() {
            node temp = head;
            while (temp != null) {
                System.out.print(temp.data + "-->");
                temp = temp.next;
            }
            System.out.println("null");
        }
    private node getMid(node head){
        node slow=head;
        node fast=head.next;
        while(fast!=null&&fast.next!=null){
            slow=slow.next;
            fast=fast.next.next;
        }
        return slow;
    }
    private node merge(node head1,node head2){
        node mergeLL=new node(-1);
        node temp=mergeLL;
        while(head1!=null&&head2!=null){
            if(head1.data<=head2.data){
                temp.next=head1;
                head1=head1.next;
                temp=temp.next;
            }else{
                temp.next=head2;
                head2=head2.next;
                temp=temp.next;

            }
        }
        while(head1!=null){
            temp.next=head1;
            head1=head1.next;
            temp=temp.next;
        }
        while(head2!=null){
            temp.next=head2;
            head2=head2.next;
            temp=temp.next;
        }
        return mergeLL.next;
    }
     public node mergeSort(node head){
        if(head==null||head.next==null){
            return head;
        }
            // find mid
            node mid=getMid(head);
            // left right mergeSort
            node rightHead=mid.next;
            mid.next=null;
            node newLeft=mergeSort(head);
            node newRight=mergeSort(rightHead);
            return merge(newLeft,newRight);
    
     }
     public static void main(String[] args) {
        mergeshortLL ll=new mergeshortLL();
        ll.addFirst(1);
        ll.addFirst(2);
        ll.addFirst(3);
        ll.addFirst(4);
        ll.addFirst(5);
        ll.print();
        ll.head=ll.mergeSort(ll.head);
        ll.print();
     
     }
}
