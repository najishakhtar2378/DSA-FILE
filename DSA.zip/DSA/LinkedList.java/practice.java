public class practice {
    public static class node{
        int data;
        node next;
    
        public node(int data){
            this.data=data;
            this.next=null;
        }
    
    }
    public static node head;
    public static node tail;

    public void addFirst(int data){
        node newNode=new node(data);
        if(head==null){
            head=tail=newNode;
            return;
        }
        newNode.next=head;
        head=newNode;
    
    }
    // for addLast
    public  void addLast(int data){
        node newNode=new node(data);
            if(head==null){
                head=tail=newNode;
                return;
            }
            tail.next=newNode;
            tail=newNode;
        }
        public void print(){
            if(head==null){
                System.out.println("null");
                return;
            }
            node temp=head;
            while(temp!=null){
                System.out.print(temp.data+"-->");
                temp=temp.next;
            }
            System.out.println("null");
        }
        public static void main(String[] args) {
            practice pp=new practice();
            pp.print();
            pp.addFirst(2);
            pp.print();
            pp.addFirst(1);
            pp.print();
            pp.addLast(3);
            pp.print();
            pp.addLast(4);
            pp.print();
        }
    }
  


