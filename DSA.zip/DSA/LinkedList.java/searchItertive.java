public class searchItertive {
  public static class node {
    int data;
    node next;

    // cunstructor
    public node(int data) {
      this.data = data;
      this.next = null;
    }
  }
  public static node head;
  public static node tail;
  public static int size;
  public void addFirst(int data) {
    // step 1st ---> create new node
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    // step 2nd----> newNode next=head
    newNode.next = head;
    // link

    // step 3----> head=new nodes
    head = newNode;
  }
  // for fx addLast
  public void addLast(int data) {
    node newNode = new node(data);
    size++;
    if (head == null) {
      head = tail = newNode;
      return;
    }
    tail.next = newNode;
    tail = newNode;
  }

  public void print() {
    node temp = head;
    while (temp != null) {
      System.out.print(temp.data + "-->");
      temp = temp.next;
    }
    System.out.println("null");
  }
  public static int iterativeSearch(int key){
    int i=0;
    node temp=head;
    while(temp!=null){
      if(temp.data==key){
        return i;
      }
      temp=temp.next;
      i++;
    }
    return -1;
  }
  // recursive method
  // public int helper(node head, int key) {
  //   if (head == null) {
  //     return -1;
  //   }
  //   if (head.data == key) {
  //     return 0;
  //   }
  //   int idx = helper(head.next, key);
  //   if (idx == -1) {
  //     return -1;
  //   }
  //   return idx + 1;
  // }
  public static void main(String[] args) {
    searchItertive ll=new searchItertive();
    ll.print();
    ll.addFirst(2);
    ll.print();
    ll.addFirst(1);
    ll.print();
    ll.addLast(3);
    ll.print();
    ll.addLast(4);
    ll.print();
    ll.addLast(5);
    System.out.println(iterativeSearch(3));
    System.out.println(iterativeSearch(2));
  }
}
