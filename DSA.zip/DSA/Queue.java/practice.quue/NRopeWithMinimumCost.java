import java.util.LinkedList;
import java.util.Queue;
public class NRopeWithMinimumCost {
  public static void main(String[] args) {
    int ropes[]={2,3,3,4,6};
    Queue<Integer>q=new LinkedList<>();
    for(int i=0;i<ropes.length;i++){
      q.add(ropes[i]);
    }
    int cost=0;
    while(q.size()>1){
      // while(q.size()>1) jabtk q ke ander ek single ropes na aa jaye tabn tk ye loopexecute krega
      int min = q.remove();
      int min1 = q.remove();
      // first min jo loop ke ander exist krta 
      // min1 jo dubara loop ke ander exist krega uske liye 
      cost += min + min1;

      q.add(min + min1);
      // q ke ander kreng dono ropes ko jodne ke baad 
    }
    System.out.println("cost of connecting ropes "+cost);
 
  }

  
}
