import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class RevealCard {
  public static int[] deckRevealCard(int deck[]){
    int n=deck.length;
    Queue<Integer> q=new LinkedList<>();
    int res[]=new int[n];
    for(int i=0;i<n;i++){
      q.add(i); //all are add in queue
    }
    Arrays.sort(deck);
    for(int i=0;i<n;i++){
      int temp=q.remove();
      res[temp]=deck[i];
      if(!q.isEmpty()){
        q.add(q.peek());
        q.remove();
      }
    }
    return res;
  }
  public static void main(String[] args) {
    int deck[]={17,13,11,2,3,5,7};
    int ans[]= deckRevealCard(deck);
    System.out.println(Arrays.toString(ans));
  }
  
}
