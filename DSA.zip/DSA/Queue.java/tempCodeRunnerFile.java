 q.add(1);
    //  q.add(2);
    //  q.add(3);