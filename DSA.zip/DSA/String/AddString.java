import java.math.BigInteger;
public class AddString {
  // public static String addStr(String num1,String num2){
  //   int p1=num1.length()-1;
  //   int p2=num2.length()-1;
  //   StringBuilder res=new StringBuilder();
  //   int  c=0,base=10;
  //   while(p1>=0|| p2>=0){
  //     int s=0,s1=0,s2=0;
  //     if(p1>=0)
  //       s1=num1.charAt(p1--)-'0';
      
  //     if(p2>=0)
  //       s2=num2.charAt(p2--)-'0';
  //       s=s1+s2+c;
      
  // after carry possiblities then 
  
  //     if(c>=base){
  //       c=1;
  //       s=s-base;
  //     }else
  //       c=0;
  //       res.append(s);
  //   }
  //in last carry genrete 1 then direct append in result

  //   if(c==1)
  //     res.append(c);
  //     return res.reverse().toString();
  // }
  //second approch used big integer
  public static String addStr(String num1, String num2) {
    BigInteger n1 = new BigInteger(num1);
    BigInteger n2 = new BigInteger(num2);
    BigInteger res = n1.add(n2);
    String s = String.valueOf(res); //change int to string
    return s;
  }
public static void main(String[] args) {
  String num1="223";
  String num2 ="456";
  System.out.println(addStr(num1, num2));

}
}
