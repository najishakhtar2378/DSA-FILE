
public class ColumnTitle {
  public static int colTitle(String coltitle) {
    int n=coltitle.length();
    int sum=0;
    int power=0;
    for (int i=n-1;i>=0;i--) {
      int temp=coltitle.charAt(i)-64; // find temp variable to store reverse string val
      sum = sum+(int)Math.pow(26, power++)*temp;//power update after sum
    }
    return sum;
  }
  public static void main(String[] args) {
    String coltitle="AB";
    System.out.println(colTitle(coltitle));
  }
  
}
