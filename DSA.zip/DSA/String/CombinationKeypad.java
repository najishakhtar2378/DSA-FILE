import java.util.ArrayList;
import java.util.List;

public class CombinationKeypad {
  public static String[] keypad = {"","", "abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
    static List<String> res;
    public static void printComb(String digits, int idx, String comb) {
      if(idx==digits.length()){
        res.add(comb);
        return;
      }
        char ch=digits.charAt(idx);
        String mapping=keypad[ch-'0'];
        for(int i=0;i<mapping.length();i++){
          printComb(digits, idx+1, comb+mapping.charAt(i));
        }
      }
    public static List<String> letterCombinations(String digits) {
        res = new ArrayList<>();
        if (digits == null || digits.length() == 0) return res;
        printComb(digits, 0, "");
        return res;
    }
  public static void main(String[] args) {
    String s="23";
    System.out.println(letterCombinations(s));
  }
}
