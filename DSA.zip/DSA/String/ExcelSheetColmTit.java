
public class ExcelSheetColmTit {
  public  static String ExcelSheet(int colNo) {
    StringBuilder sb = new StringBuilder();
    while (colNo > 0) {
      int rem = (colNo - 1) % 26; // find remainder
    //  rem + 'A': Adds the number rem to the ASCII value of 'A'. So if rem = 0, it becomes 65 (which is 'A'); if rem = 1, it becomes 66 (which is 'B'), etc.
      sb.append((char) (rem + 'A'));
      // reduced colNo
      colNo = (colNo - 1) / 26;
    }
    // string found at reverse order then use reverse fx
    return sb.reverse().toString();
  }
  public static void main(String[] args) {
    int colNo=701;
    System.out.println(ExcelSheet(colNo));
   //important
    //700%26=24  [700 modulo 26 =24]
    // 25%26=25
  }
  
}
