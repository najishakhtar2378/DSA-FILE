public class FindDiffrence {
  public static  char findTheDifference(String s, String t) {
    int count[] = new int[26];
    for (char ch : t.toCharArray()) { // t have more char
      count[ch - 'a']++; // jo v char aayega usko 1 se count krenge
    }
    for (char ch : s.toCharArray()) {
      count[ch - 'a']--; // s ke char ke freq ko subtract krenge
    }
    // loop run 0 to 26 char
    for (int i = 0; i < 26; i++) {
      if (count[i] == 1) {
        return (char) (i + 'a');
      }
    }
    return ' ';
  }
  public static void main(String[] args) {
    String s="abcd";
    String t="abcde";
    System.out.println(findTheDifference(s, t));
  }
  
}
