public class FindLongestBalancedSubstringBinaryString {
  public static int findTheLongestBalancedSubstring(String s) {
    int res = 0;
    // initialize temp varible with 2 size "01" && check given string
    String temp = "01"; // initialize in starting

    while (temp.length() <= s.length()) {
      if (s.contains(temp)) { // cheack temp is exist in given string
        res = temp.length();
      }
      temp = '0' + temp + '1'; // add 0 and 1 for next itteration temp initialize 01->0011->000111
    }
    return res;
  }

  public static void main(String[] args) {
    String s="01000111";
    System.out.println(findTheLongestBalancedSubstring(s));
  }
}
