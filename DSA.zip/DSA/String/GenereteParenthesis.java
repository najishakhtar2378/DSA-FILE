import java.util.ArrayList;
import java.util.List;
public class GenereteParenthesis {
   static List<String>ans;
    public static void generete(StringBuilder sb, int open,int close){
        if(open==0 && close==0){ //base case
            ans.add(sb.toString());
            return;
        }
        if(open>0){  //for open parenthesis
            sb.append('(');
            generete(sb,open-1,close);
              sb.deleteCharAt(sb.length() - 1); //backtracking
            }
        if(close>0){
            if(open<close){ //for close parenthesis
                sb.append(')');
                generete(sb,open,close-1);
                sb.deleteCharAt(sb.length() - 1); // backtracking
            }
        }
    }
    public static List<String> generateParenthesis(int n) {
        ans=new ArrayList<>();
        generete(new StringBuilder(),n,n);
        return ans;
    }
    public static void main(String[] args) {
      int n=3;
      System.out.println(generateParenthesis(n));
    }
  
}
