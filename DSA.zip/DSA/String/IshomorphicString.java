import java.util.HashMap;

public class IshomorphicString {
   public static  boolean isIsomorphic(String s, String t) {
        if(s.length()!=t.length()){
            return false;
        }
        HashMap<Character,Character> hm1=new HashMap<>();
        HashMap<Character,Boolean> hm2= new HashMap<>();

        int n=s.length(); //you can found also t length
        for(int i=0;i<n;i++){
            char ch1=s.charAt(i);
            char ch2=t.charAt(i);
            if(hm1.containsKey(ch1)==true){
                if(hm1.get(ch1)!=ch2) //g ka mapping d se na hoke koi or letter se hoga tb ex s ho last me
                return false;
          }else{
            if(hm2.containsKey(ch2)==true) // allready character are used then not used next time
            return false;

            else{
                hm1.put(ch1,ch2);
                hm2.put(ch2,true);
            }
          }
        }
        return true;
    }
    public static void main(String[] args) {
      String s="egg";
      String t="agg";
      System.out.println(isIsomorphic(s, t));

    // e-->a
    // g-->d
    // g-->d

    }
}
