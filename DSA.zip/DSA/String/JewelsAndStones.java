import java.util.HashSet;
import java.util.Set;

public class JewelsAndStones {
  public static int jewelsStone(String jewels,String stones){
    int count=0;
    Set<Character> hs=new HashSet<>();
    for(char c:jewels.toCharArray()){
      hs.add(c);
    }
    for(int i=0;i<stones.length();i++){
      if(hs.contains(stones.charAt(i))){
        count++;
      }
    }
    return count;

  }
  public static void main(String[] args) {
    String jewels="aA";
    String stones="aAAbbb";
    System.out.println(jewelsStone(jewels,stones));
  }
  
}
