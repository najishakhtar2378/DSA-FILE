import java.util.LinkedList;
import java.util.List;
public class KeyBoardRoww {
  public static String[] keybord(String words[]){
    String row1="qwertyuiop";
    String row2="asdfghjkl"; 
    String row3="zxcvbnm";
    List<String> res=new LinkedList<>();
    for(String word:words){
      int rows[]=new int[3];
      for(char ch:word.toLowerCase().toCharArray()){

        // when word cames 0th row then row[0] will be 1
        if(row1.indexOf(ch)!=-1)
        rows[0]=1;
        // when word cames 1st row then row[1] will be 1
        if(row2.indexOf(ch)!=-1)
        rows[1]=1;
        // when word cames 2nd row then row[2] will be 1
        if(row3.indexOf(ch)!=-1)
        rows[2]=1;
      }
      // when doing sum of all rows then output gives 1 we found word
      int sum=rows[0]+rows[1]+rows[2];
      if(sum==1)
      res.add(word);
      System.out.println(res);
    }
    String arr[]=new String[res.size()];
    int i=0;
    for(String word:res)
    arr[i++]=word;
    return arr;
  }
  public static void main(String[] args) {
    String words[]={"Hello","Alaska","Dad","Peace"};
    keybord(words);
  
  }
}
