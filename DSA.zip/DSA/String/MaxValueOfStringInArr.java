public class MaxValueOfStringInArr {
  public static int maxLenth(String[] strs){
   int maxLen=0;
   for(String s:strs){ //convert arr to String
       //find max
       maxLen=Math.max(maxLen,find(s));
   }
   return maxLen;
  }
   public static int find(String s){
       for(int i=0;i<s.length();i++){
        char ch=s.charAt(i);
        if(ch>='a' && ch<='z'){ // check all char are lowercase And detect word or a number
          return s.length();//return maxLenth of String
        }
       }
       return Integer.parseInt(s); // only for numeic number
      }
      public static void main(String[] args) {
        String strs[]={"alic3","bob","3","4","00000"};
        System.out.println(maxLenth(strs));
      }
      }
