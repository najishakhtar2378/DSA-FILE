public class MinSubSequenceBinString {
  static int countOne=0;
  public static String minSubsequence(String s) {
        StringBuilder result = new StringBuilder();
        int countZero = 0;
        // Count how many 0s and 1s are there
        for (char c : s.toCharArray()) {
            if (c == '0') {
            countZero++;
             } else {
              countOne++;
      }
    }
        for (char c : s.toCharArray()) {
            if (c == '0') {
                // Always take the first zero you encounter
                result.append('0');
                break;
            } else {
              countOne--;
                if (countZero == 0) {
                    result.append('1');
                    break;
                }
            }
        }
        return result.toString();
    }

    public static void main(String[] args) {
        String s1 = "1101";
        String s2 = "1111";
        String s3 = "00101";
        System.out.println(minSubsequence(s3));
  
}
}