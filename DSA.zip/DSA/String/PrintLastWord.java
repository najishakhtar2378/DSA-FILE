
public class PrintLastWord {
  public static String lengthOfLW(String s){
    StringBuilder sb = new StringBuilder();
    for(int i=s.length()-1;i>=0;i--){
      char ch = s.charAt(i);
      if (ch != ' ') {
        sb.append(s.charAt(i));
      } else if (s.charAt(i) != 0) {
        break;
      }
    }
    return sb.reverse().toString();
  }
  public static void main(String[] args) {
    String s="Hello World";
    System.out.println(lengthOfLW(s));
  }
}
