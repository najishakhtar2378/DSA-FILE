
public class PrintStartingWord {
  public static String lengthOfSW(String s){
    StringBuilder sb = new StringBuilder();
    for(int i=s.length()-1;i>=0;i--){
    // for (int i = 0; i < s.length(); i++) {
      char ch = s.charAt(i);
      if (ch != ' ') {
        sb.append(s.charAt(i));
      } else if (s.charAt(i) != 0) {
        break;
      }
    }
    return sb.toString();
  }
  public static void main(String[] args) {
    String s="Hello world";
    System.out.println(lengthOfSW(s));
  }
}
