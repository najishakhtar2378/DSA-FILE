public class ReapetdeSubstrpat {
  public static boolean repeatedSubStr(String s){
    int n=s.length();
    // reverse cheack substring n/2 length 
    for(int i=n/2;i>=1;i--){
      if(n%i==0){
        String substr=s.substring(0,i); // string function to store small substr
        StringBuilder newStr=new StringBuilder();
        // all samall subtstr add
        for(int j=1;j<=n/i;j++)
        newStr.append(substr);
        //chaeck newStr equal to given String
         if(newStr.toString().equals(s))
         return true;
    }
  }
  return false;
}
public static void main(String[] args) {
  String s="abab";System.out.println(repeatedSubStr(s));
}
}