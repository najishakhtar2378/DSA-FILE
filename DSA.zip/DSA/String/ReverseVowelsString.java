
public class ReverseVowelsString {
  public static String reverseVowels(String s) {
    char arr[] = s.toCharArray(); // convert String from an array
    int i = 0;
    int j = arr.length - 1;
    String vowels = "aeiouAEIOU";
    while (i < j) {
      while (i < j) {
        char ch = arr[i];
        if (vowels.indexOf(ch) != -1) // ith char vowels na ho tb
          break;
        i++;
      }
      while (i < j) {
        char ch = arr[j];
        if (vowels.indexOf(ch) != -1)// jth char vowels na ho tb
          break;
        j--;
      }
      // when vowels are found where ith and jth place then swaping
      char temp = arr[i];
      arr[i] = arr[j];
      arr[j] = temp;
      i++;
      j--;
    }
    return new String(arr);
  }
  public static void main(String[] args) {
    String s="leetcode";
    System.out.println(reverseVowels(s));
  }
  
}
