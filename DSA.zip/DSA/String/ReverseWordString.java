public class ReverseWordString {
  public static  String reverseWords(String s) {
    // .split(" ") means: cut the string at every space. and store the word in an arr[]
    String arr[] = s.split(" ");
    StringBuilder sb = new StringBuilder();
    for (int i = arr.length - 1; i >= 0; i--) {
      if (arr[i].length() == 0) { // find empty string
        continue;
      }
      // found new word
      if (sb.length() == 0) { // empty will be in starting
        // after found 1st word then append
        sb.append(arr[i]);
      } else {
        sb.append(" ");
        sb.append(arr[i]);
      }
    }
    return sb.toString();
  }
  public static void main(String[] args) {
    String s=" the sky is blue";
    System.out.println(reverseWords(s));
    //output are
    // arr[0]=blue
    // arr[1]=is
    // arr[2]=sky
    // arr[3]=the

  }
  
}
