import java.util.Arrays;
import java.util.HashMap;
public class SortPeople {
  public static String[] sortPeople(String names[],int heights[]){
    HashMap<Integer,String>hm=new HashMap<>();
     for(int i=0;i<names.length;i++){
      hm.put(heights[i],names[i]);
     }
    Arrays.sort(heights);
    String res[]=new String[heights.length];
    int idx=0;
    for(int i=heights.length-1;i>=0;i--){
       res[idx]=hm.get(heights[i]);
    }
    return res;
  }
  public static void main(String[] args) {
    String names[]={"Marry,john,Emma"};
    int heigths[]={180,165,170};
    System.out.println(sortPeople(names, heigths));
  }
}
