import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class StringPattern {
   public static  boolean wordPattern(String pattern, String s) {
        HashMap<Character,String>hm1=new HashMap<>();
        Set<String>st=new HashSet<>();
         String arr[]=s.split(" ") ;//split string in word on the basis of space 
         int n=arr.length;
         if(n!=pattern.length()){ // arr ke length aur pattern ke length jab eqaula na ho tb
            return false;
         }
         for(int i=0;i<n;i++){
           String word=arr[i];
            char ch=pattern.charAt(i);

            if(hm1.containsKey(ch)){ //agr koi char map ho tb
                if(!hm1.get(ch).equals(word)) //agr a dog se maped h but a kisi or se mapped kre tb
                    return false;
            }else{
                if(st.contains(word)) // agr word use ho gya ho tb again word ko nhi lenge or
                //false return kra denge { yani ek hi word ko baar bar nhi lenge}
                return false;
            else{ // jab map use nhi hua aur set v use nhi hua tb
                hm1.put(ch,word); //map me ch aur word ko dalenge
                st.add(word); //set ke ander word ko add kr denge 

            }
         }
         }
         return true;
    }
    public static void main(String[] args) {
      String pattern="abba";
      String s="dog cat cat dog";
      System.out.println(wordPattern(pattern, s));
      
    }
  
}
