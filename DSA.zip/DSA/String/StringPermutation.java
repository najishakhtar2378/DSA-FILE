import java.util.Arrays;
public class StringPermutation {
  public static boolean checkInclusion(String s1, String s2) {
        int n = s1.length();
        int m = s2.length();
        if (n > m) {
        return false;
        }
        int[] s1freq = new int[26];
        int[] s2freq = new int[26];

        for (int i = 0; i < n; i++) {
            s1freq[s1.charAt(i) - 'a']++;
        }
        // sliding window check s1 elements exist in s2
        int i = 0, j = 0;
        while (j < m) {
            s2freq[s2.charAt(j) - 'a']++;
            if (j - i + 1 > n) {
                s2freq[s2.charAt(i) - 'a']--;
                i++;
            }
            // check both freq are same
            if (Arrays.equals(s1freq, s2freq)) {
                return true;
            }
            j++;
        }
        return false;
}
public static void main(String[] args) {
  String s1="ab";
  String s2="eidbaooo";
  System.out.println(checkInclusion(s1, s2));
}
}