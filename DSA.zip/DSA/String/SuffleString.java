import java.util.HashMap;
public class SuffleString {
   public static String restoreString(String s, int[] indices) {
        int len=indices.length;
        HashMap<Integer,Character> hm=new HashMap<>();
        for(int i=0;i<len;i++){
          hm.put(indices[i],s.charAt(i));
        }
        StringBuilder sb =new StringBuilder();
        for(int i=0;i<len;i++){
          sb.append(hm.get(i));
        }
        return sb.toString();
    }
    public static void main(String[] args) {
      String s = "codeleet";
      int indices[]={4,5,6,7,0,2,1,3};
      System.out.println(restoreString(s, indices));
      
    }
  

}
