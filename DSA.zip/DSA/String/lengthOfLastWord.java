
public class lengthOfLastWord {
  public static int lengthOfLW(String s){
    int count=0;
    for(int i=s.length()-1;i>=0;i--){
      char ch=s.charAt(i);
      if(ch!=' '){
        count++;
      }
      else if(count!=0){
        break;
      }
    }
    return count;
  }
  public static void main(String[] args) {
    String s="Hello World";
    System.out.println(lengthOfLW(s));
  }
}
