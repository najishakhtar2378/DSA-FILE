
public class longestCommonPrefix {
  public static String commonsub(String s1, String s2) {
    int n = Math.min(s1.length(), s2.length());
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < n; i++) {
      if (s1.charAt(i) == s2.charAt(i)) {
        sb.append(s1.charAt(i)); // when s1 and s2 are equal then we can sb.append any
      } else {
        break;
      }
    }
    return sb.toString();
  }

  public static  String longestCommonPrefix(String[] strs) {
    String res = strs[0];
    for (int i = 1; i < strs.length; i++) {
      // commonSub call
      res = commonsub(res, strs[i]);
    }
    return res;
  }
  public static void main(String[] args) {
    String strs[]={"abc","abcd","abe"};
    System.out.println(longestCommonPrefix(strs));
  }
}