public class rotateString {
  public static boolean rotateString(String s ,String goal){
    String S1=s+s;
    if(S1.contains(goal) && s.length()==goal.length()){
      return true;
    }
    return false;
  }
  public static void main(String[] args) {
    String s="abcde";
    String goal="cdeab";

    System.out.println(rotateString(s, goal));
  }
  
}
