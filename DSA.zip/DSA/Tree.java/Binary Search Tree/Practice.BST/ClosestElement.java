public class ClosestElement {
  static class Node {
    int data;
    Node left;
    Node right;

    Node(int data) {
      this.data = data;
      this.left = null;
      this.right = null;
    }
  }
  public static Node findClosest(Node root,int value){
    if(root==null){
      return null;
    }
    int minDiff=Integer.MAX_VALUE;
    Node closestElement =null;
    while(root!=null){
      int currDiff=Math.abs(root.data-value);
      if(currDiff<minDiff){
        minDiff=currDiff;
        closestElement=root;
      }
      if(value<root.data){
        root=root.left;
      }else if(value>root.data){ 
        root=root.right;
      }else{
        break;
      }

    }
    return closestElement;
  }
  public static void main(String[] args) {
    Node root = new Node(8);
    root.left = new Node(6);
    root.left.left = new Node(5);
    root.left.left.left = new Node(3);
    root.right = new Node(10);
    root.right.right = new Node(11);
    root.right.right.right = new Node(12);
   int value=7;
  //  preorder(root);
  
   
    
  }
  
}
