
public class DeleteLeafNode {
  static class Node {
    int data;
    Node left;
    Node right;

    Node(int data) {
      this.data = data;
      this.left = null;
      this.right = null;
    }
  }
  public static Node deleteLeafNode(Node root,int x){
    if(root==null){
      return root;

    }
    root.left=deleteLeafNode(root.left, x);
    root.right=deleteLeafNode(root.right, x);
    // process to parent
    if(root.left==null&&root.right==null&&root.data==x){
      return null;
    }
    return root;
  }
  // preorder traverasal
   public static void inorder(Node root){
      if (root == null){
        return ;
      }
       inorder(root.left);
       System .out.print(root.data + " ");
       inorder(root.right);
}
  public static void main(String[] args) {
    Node root = new Node(1);
    root.left = new Node(2);
    root.right = new Node(2);
    root.left.left = new Node(2);
    root.left.right = new Node(5);
    root.right.left = new Node(6);
    root.right.right = new Node(2);
    int x=2;
    deleteLeafNode(root, x);
    System.out.print("Inorder traversal after deletion : ");
    inorder(root);
  }
  
}
