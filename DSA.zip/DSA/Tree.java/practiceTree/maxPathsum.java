public class maxPathsum {
  static class Node {
    int data;
    Node left;
    Node right;

    Node(int data) {
      this.data = data;
      this.left = null;
      this.right = null;
    }
  }
  public static int maxPath(Node root,int ans){
    if(root==null){
      return 0;
    }
    int left=maxPath( root.left, ans);
    int right=maxPath(root.right, ans);
    int nodeMax=Math.max(Math.max(root.data,root.data+left+right),
          Math.max(root.data+left,root.data+right));

        ans=Math.max(ans,nodeMax);

          // Anceestor include path
     int singlePathSum=Math.max(root.data,Math.max(root.data+left,root.data+right));
          return singlePathSum;
  }
     public static  int maxPathSum(Node root){
       int ans=Integer.MAX_VALUE;
        maxPath(root,ans);
        return ans;
  }

  public static void main(String[] args) {
    Node root = new Node(1);
    root.left = new Node(2);
    root.right = new Node(3);
    root.left.left = new Node(4);
    root.left.right = new Node(5);
    root.right.left=new Node(6);
    root.right.right = new Node(7);
    System.out.println(maxPathSum(root));
    // System.out.println(maxPath(root, 0));
    

    
  }
  
}
