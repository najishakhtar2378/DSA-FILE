public class startWithProblem {
  static class Node {
    Node children[] = new Node[26];
    boolean eow = false;

    // eow end od word
    Node() {
      for (int i = 0; i < 26; i++) {
        children[i] = null;
      }
    }
  }
  
  public static Node root = new Node();

  public static void insert(String word) {
    Node curr = (root);
    for (int leval = 0; leval < word.length(); leval++) {
      int idx = word.charAt(leval) - 'a';
      if (curr.children[idx] == null) {

        // node create on curr children
        curr.children[idx] = new Node();
      }
      curr = curr.children[idx];
    }
    curr.eow = true;
  }

  // search key
  public static boolean search(String key) {
    Node curr = root;
    for (int leval = 0; leval < key.length(); leval++) {
      int idx = key.charAt(leval) - 'a';
      if (curr.children[idx] == null) {
        return false;
      }
      curr = curr.children[idx];
    }
    // last index return true
    return curr.eow == true;
  }
  public static boolean StartsWith(String prefix){
    Node curr=root;
    for(int i=0;i<prefix.length();i++){
      int idx=prefix.charAt(i)-'a';
      if(curr.children[idx]==null){
        return false;
      }
      curr=curr.children[idx];
    }
    return true;
  }
  public static void main(String[] args) {
    String words[]={"apple","app","mango","man","woman"};
    String prefix1="app";
    String prefix2="moon";
    for(int i=0;i<words.length;i++){
      insert(words[i]);
    }
    System.out.println(StartsWith(prefix1));
    System.out.println(StartsWith(prefix2));
  }
  
}
