public class buyAndSell {
    public static int buyAndSell(int pricess[]){
    //     int buyprice=Integer.MAX_VALUE;
    //     int maxProfit=0;
    //     for(int i=0;i<pricess.length;i++){
    //         if( buyprice<pricess[i]){
    //            int profit=pricess[i]-buyprice;
    //            maxProfit=Math.max(maxProfit, profit);
    //         }
    //         else{
    //             buyprice=pricess[i];
    //         }
    //     }
    //       return maxProfit;
    // }
    // public static void main(String[] args) {
    //     int pricess[]={7,1,5,3,6,4};
    //     System.out.println(buyAndSell(pricess));
    int buyprice=Integer.MAX_VALUE;
    int maxProfit=0;
    for(int i=0;i<pricess.length;i++){
        if(buyprice<pricess[i]){
            int profit=pricess[i]-buyprice;
            maxProfit=Math.max(maxProfit,profit);
    }
    else{
        buyprice=pricess[i];
    }
}
return maxProfit;
    
}
public static void main(String[] args) {
    int pricess[]={2,4,6,5,7};
    System.out.println(buyAndSell(pricess));
}
}
