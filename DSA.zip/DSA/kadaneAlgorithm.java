public class kadaneAlgorithm {
public static void kadanes2(int numbers[]){
//     int cs=0;
//     int ms=Integer.MIN_VALUE;
//     for(int i=0;i<numbers.length;i++){
//         cs=cs+numbers[i];
//     if(cs<0){
//         cs=0;
//     }
//     ms=Math.max(cs,ms);
// }
// System.out.println("our maximum subarray:"+ms);
// }

// public static void main(String[] args) {
//     int numbers[]= {-3,-4,-1,3,5,7,-8};
//     kadanes2(numbers);
    
  int cs=0; // cs=current sum
  int ms=Integer.MIN_VALUE;
  for(int i=0;i<numbers.length;i++){
    cs=cs+numbers[i];
    ms = Math.max(cs, ms);
    if(cs<0){
        cs=0;
    }
    // ms=Math.max(cs,ms);
  }
  System.out.println("our maxSum is:"+ms);
}
public static void main(String[] args) {
    // int numbers[]={-2,-3,4,-1,-2,1,5,-3};
    // int numbers[]={2,-5,1,-4,3,-2};
    int numbers[]={-2,1,-3,4,-1,2,1,-5,4};
    kadanes2(numbers);
}
}
