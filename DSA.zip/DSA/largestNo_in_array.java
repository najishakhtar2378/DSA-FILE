public class largestNo_in_array {

    // find the largest & smallest number in given array
    public static int getLargest(int numbers[]){
    //     int largest=Integer.MIN_VALUE; 
    //     int smallest=Integer.MAX_VALUE; 

    //     // where min_value is represented by -infinity
    //     for(int i=0;i<numbers.length;i++){
    //         if(largest<numbers[i]){
    //             largest=numbers[i];
    //         }
    //         if(smallest>numbers[i]){
    //             smallest=numbers[i];
    //          }
    //          System.out.println("smallest value is " +smallest);
    //     }
    //     return largest;
    // }
    // public static void main(String[] args) {
    //     int numbers[]={2,5,6,3,1};
    //     System.out.println("largest value is " +getLargest(numbers));

    //  problem 01
       int largest=Integer.MIN_VALUE;
       for(int i=0;i<numbers.length;i++){
        if(largest<numbers[i]){
            largest=numbers[i];
        }
        // System.out.println("largest value is:"+largest);
       }
       return largest;
    }
    public static void main(String[] args) {
        int numbers[]={4,3,7,4,8,6,9};
        System.out.println(getLargest(numbers));
    }
}

