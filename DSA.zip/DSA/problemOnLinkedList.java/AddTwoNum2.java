public class AddTwoNum2 {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  public ListNode reverseList(ListNode head) {
    ListNode prev = null;
    ListNode curr = head;

    while (curr != null) {
      ListNode next = curr.next;
      curr.next = prev;
      prev = curr;
      curr = next;
    }

    return prev;
  }

  public ListNode helper(ListNode l1, ListNode l2) {
    ListNode dummyHead = new ListNode(0);
    ListNode curr = dummyHead;
    int carry = 0;
    // add two number
    while (l1 != null || l2 != null || carry != 0) {
      int digit1 = (l1 != null) ? l1.val : 0;
      int digit2 = (l2 != null) ? l2.val : 0;

      int sum = digit1 + digit2 + carry;
      int digit = sum % 10;
      carry = sum / 10;

      ListNode newNode = new ListNode(digit);
      curr.next = newNode;
      curr = curr.next;

      l1 = (l1 != null) ? l1.next : null;
      l2 = (l2 != null) ? l2.next : null;
    }

    ListNode result = dummyHead.next;
    return result;
  }

  // reverse linkedlist
  public  ListNode addTwoNumbers(ListNode l1, ListNode l2) {
    l1 = reverseList(l1);
    l2 = reverseList(l2);
    ListNode ans = helper(l1, l2);
    return reverseList(ans);
  }
  public static void main(String[] args) {
    
  }
}
