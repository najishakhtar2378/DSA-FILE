public class AddtwoNumber {
  public static class ListNode {
    int val;
   ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  public static ListNode addTwoNumbers(ListNode l1, ListNode l2) {
    // Dummy head to simplify result list construction
    ListNode dummyHead = new ListNode(0);
    ListNode current = dummyHead;
    int carry = 0;

    // Loop through lists l1 and l2 until both are null and carry is 0
    while (l1 != null || l2 != null || carry != 0) {
      // Get values from the current nodes; if null, use 0
      int val1 = (l1 != null) ? l1.val : 0;
      int val2 = (l2 != null) ? l2.val : 0;

      // Calculate sum and carry
      int sum = val1 + val2 + carry;
      carry = sum / 10;

      // Create a new node with the digit(res) value of sum
      current.next = new ListNode(sum % 10);
      current = current.next;

      // Move to the next nodes in l1 and l2
      if (l1 != null)
        l1 = l1.next;
      if (l2 != null)
        l2 = l2.next;
    }

    // return
    return dummyHead.next;
  }
  
  public void printList(ListNode head) {
    ListNode curr = head;
    while (curr != null) {
      System.out.print(curr.val + " ");
      curr = curr.next;
    }
    System.out.println();
  }

public static void main(String[] args){
}
  
}
