public class ConvertBinaryNumLL{
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  
  public int getDecimalValue(ListNode head) {
    int res = 0;
    while (head != null) {
      res = (res << 1) | (head.val);
      head = head.next;
    }
    return res;

  }
  public static void main(String[] args) {
    
  }
}