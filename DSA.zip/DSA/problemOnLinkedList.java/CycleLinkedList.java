public class CycleLinkedList {
  class ListNode {
    int val;
    ListNode next;
    public ListNode(int val) {
      this.val = val;
      this.next = null;
    }
  }
  public ListNode detectCycle(ListNode head) {
    ListNode slow = head;
    ListNode fast = head;

    while (fast != null && fast.next != null) {
      slow = slow.next;
      fast = fast.next.next;

      if (slow == fast) {
        break;
      }
    }
    if (fast == null || fast.next == null) {
      return null;
    }
    while (head != slow) {
      head = head.next;
      slow = slow.next;
    }
    return head;
  }
  public static void main(String[] args) {
    
  }
  
}
