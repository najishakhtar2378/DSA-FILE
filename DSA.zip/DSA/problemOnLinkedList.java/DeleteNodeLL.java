public class DeleteNodeLL {
class ListNode {
   int val;
   ListNode next;
   public  ListNode(int val){
    this.val=val;
    this.next=null;
   }
  }
    public void deleteNode(ListNode node) {
        node.val = node.next.val; //node ke val ko  node.next.val se copy kreneg
        
        node.next = node.next.next; //node.next replace hoga node.next.next
    }
    public static void main(String[] args) {
      
    }
}


