public class MergeTwoSortedLL {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  public ListNode mergeTwoLists(ListNode head1, ListNode head2) {
    // base case
    if (head1 == null || head2 == null) {
      return head1 == null ? head2 : head1;
    }
    // case 1
    if (head1.val <= head2.val) { // jab head chhota h tb
      head1.next = mergeTwoLists(head1.next, head2);
      return head1;
    } else {
      head2.next = mergeTwoLists(head1, head2.next);
      return head2;
    }
  }
  public static void main(String[] args) {
    
  }
  
}
