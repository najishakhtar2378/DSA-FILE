public class RemoveDuplicate2 {
  class ListNode {
    int val;
    ListNode next;

    public ListNode(int val) {
      this.val = val;
      this.next = null;
    }
  }
  
  public ListNode deleteDuplicates(ListNode head) {
    if (head == null || head.next == null) {
      return head;
    }
    ListNode dummyNode = new ListNode(0);
    dummyNode.next = head;
    ListNode prev = dummyNode;
    ListNode curr = head;
    while (curr != null && curr.next != null) {
      if (curr.val == curr.next.val) { // jab curr.val==curr.next.val
        while (curr.next != null && curr.val == curr.next.val) {
          curr = curr.next;
        }
        prev.next = curr.next; // skip all duplicate node
      } else {
        prev = prev.next;
      }
      curr = curr.next;// when curr.val !=curr.next.val

    }
    return dummyNode.next;
  }
  public static void main(String[] args) {
    
  }
}
