public class RemoveDuplicateLL {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  
  public ListNode deleteDuplicates(ListNode head) {
    ListNode ans = head;
    while (head != null && head.next != null) {
      if (head.val == head.next.val) {
        head.next = head.next.next;
      } else {
        head = head.next;
      }
    }
    return ans;

  }
}
