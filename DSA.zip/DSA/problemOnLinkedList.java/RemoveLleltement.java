public class RemoveLleltement {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode() {
      // this.val = data;
      this.next = null;
    }
  }
  public static ListNode removeElements(ListNode head, int val) {
    if (head == null) {
      return null;
    }
    ListNode dummyNode = new ListNode();
    dummyNode.next = head;
    ListNode curr = dummyNode;

    while (curr.next != null) { // jab head null na ho tb
      if (curr.next.val == val) {
        curr.next = curr.next.next;
      } else {
        curr = curr.next;
      }

    }
    return dummyNode.next;
  }
  public static void main(String[] args) {
    
  }
}
