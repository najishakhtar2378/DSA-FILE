public class RemoveNodeFromLL {
  public static class ListNode {
    int val;
    ListNode next;
    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
public ListNode removeNodes(ListNode head) {
  if (head != null) {
    head.next = removeNodes(head.next); // recurse till end then reconstruct it
    if (head.next != null && head.val < head.next.val) {
      return head.next; // skip current node if smaller than right-side node
    }
  }
  return head; // otherwise keep currnode
}
public static void main(String[] args) {
  
}
}
