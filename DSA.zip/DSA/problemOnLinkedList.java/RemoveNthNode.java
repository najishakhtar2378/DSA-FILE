public class RemoveNthNode {
  class ListNode {
    int val;
    ListNode next;

    public ListNode(int val) {
      this.val = val;
      this.next = null;
    }
  }
  public ListNode removeNthFromEnd(ListNode head, int n) {
    ListNode dummyNode = new ListNode(0);
    dummyNode.next = head;
    ListNode fast = dummyNode;
    ListNode slow = dummyNode;

    for (int i = 0; i <= n; i++) {
      fast = fast.next;
    }
    while (fast != null) {
      fast = fast.next;
      slow = slow.next;
    }
    slow.next = slow.next.next; // deleted node
    return dummyNode.next;
  }
  public static void main(String[] args) {
    
  }
  
}
