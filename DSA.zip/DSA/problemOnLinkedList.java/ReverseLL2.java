public class ReverseLL2 {
  class ListNode {
    int val;
    ListNode next;

    public ListNode(int val) {
      this.val = val;
      this.next = null;
    }
  }
public ListNode reverseBetween(ListNode head, int left, int right) {
  if (head == null || head.next == null) {
    return head;
  }
  ListNode dummyNode = new ListNode(0);
  dummyNode.next = head;
  ListNode prev = dummyNode;
  for (int i = 1; i < left; i++) {
    prev = prev.next;
  }
  ListNode curr = prev.next;
  for (int i = 1; i <= right - left; i++) { // loop itterate 4-2=2times
    ListNode temp = prev.next; // store prev.next value
    prev.next = curr.next;
    curr.next = curr.next.next;
    prev.next.next = temp;
  }
  return dummyNode.next;
}
public static void main(String[] args) {
  
}
}