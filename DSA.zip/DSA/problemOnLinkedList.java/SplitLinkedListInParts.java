public class SplitLinkedListInParts {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  
  public ListNode[] splitListToParts(ListNode head, int k) {
    ListNode[] res = new ListNode[k];

    int len = 0;
    ListNode curr = head;
    while (curr != null) {
      len++;
      curr = curr.next;
    }
    int eachBucketNode = len / k;
    int remainingBucketNode = len % k;

    curr = head;
    ListNode prev = null;
    for (int i = 0; i < k; i++) {
      res[i] = curr;
      for (int count = 1; count <= eachBucketNode + (remainingBucketNode > 0 ? 1 : 0); count++) {
        prev = curr;
        curr = curr.next;
      }
      if (curr != null)
        prev.next = null; // seprete all nodes
      remainingBucketNode--; // which node are used then --
    }
    return res;

  }
  public static void main(String[] args) {
    
  }
  
}
