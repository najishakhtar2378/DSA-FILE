public class SwappingNodesLL {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  public ListNode swapNodes(ListNode head, int k) {
    ListNode p1 = null;
    ListNode p2 = null;
    ListNode temp = head;

    while (temp != null) {
      if (p2 != null) {
        p2 = p2.next;
      }
      k--;
      if (k == 0) {
        p1 = temp; // p1.val store in temp means p1 found
        p2 = head; // activated
      }
      temp = temp.next;
    }
    // swap
    int t = p1.val;
    p1.val = p2.val;
    p2.val = t;
    return head;
  }
  public static void main(String[] args) {
    
  }
  
}
