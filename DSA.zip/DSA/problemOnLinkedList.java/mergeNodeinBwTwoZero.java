public class mergeNodeinBwTwoZero {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  public ListNode mergeNodes(ListNode head) {
    head = head.next;
    ListNode start = head;
    while (start != null) {
      ListNode end = start;
      int sum = 0;
      while (end.val != 0) {
        sum += end.val;
        end = end.next;
      }
      start.val = sum; // update start.val with sum
      start.next = end.next; // linked
      start = start.next; // update start with next sum
    }
    return head;

  }
  public static void main(String[] args) {
    
  }
  
}
