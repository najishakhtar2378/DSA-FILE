public class rotateList {
  class ListNode {
    int val;
    ListNode next;

    public ListNode(int val) {
      this.val = val;
      this.next = null;
    }
  }
  public ListNode rotateRight(ListNode head, int k) {
    if (head == null || head.next == null) {
      return head;
    }
    // calculate size
    ListNode temp = head;
    int size = 0;
    while (temp != null) {
      size++;
      temp = temp.next;
    }
    // calculate rotation
    int rotation = k % size;

    for (int i = 0; i < rotation; i++) {
      ListNode last = head;
      ListNode prev = null;

      while (last.next != null) {
        prev = last;
        last = last.next;
      }
      last.next = head;
      prev.next = null;
      head = last;
    }
    return head;
  }
  public static void main(String[] args) {
    
  }
  
}
