import java.util.Stack;
public class ClearDigit {
  public static String clearDigit(String s){
    Stack<Character> st= new Stack<>();
    for(int i=0;i<s.length();i++){
      char ch=s.charAt(i);
      if(ch>='0' && ch<='9'){ //alphanumeric character
        st.pop();
      }else{
        st.push(ch);
      }
    }
    StringBuilder sb=new StringBuilder();
      for(char c:st){
        sb.append(c);
      }   
      return sb.toString();
  }
  public static void main(String[] args) {
    String s="cbd34";
    System.out.println(clearDigit(s));
  }
}
