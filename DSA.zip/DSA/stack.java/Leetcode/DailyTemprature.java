import java.util.Arrays;
import java.util.Stack;
public class DailyTemprature {
  public static int[] Dailytem(int[] temp){
    Stack<Integer>st=new Stack<>();
    int ans[]= new int[temp.length];
    for(int i=0;i<temp.length;i++){
      while(!st.isEmpty() && temp[st.peek()]<temp[i]){
        int currPopidx=st.pop();
        ans[currPopidx]=i-currPopidx;
      }
      st.push(i);
    }
    System.out.println(Arrays.toString(ans));
    return ans;
  }
  public static void main(String[] args) {
    DailyTemprature dt=new DailyTemprature();
    int temp[]={73,74,75,71,69,72,76,73};
    dt.Dailytem(temp);
  }
  
}
