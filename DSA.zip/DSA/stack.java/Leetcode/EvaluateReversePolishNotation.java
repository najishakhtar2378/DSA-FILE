import java.util.Stack;
public class EvaluateReversePolishNotation {
  public static int RPN(String[] tokens){
    Stack<Integer> st =new Stack<>();
    String oprator="+-*/";
    for(String token:tokens){
      if(oprator.contains(token)){
        int d1=st.pop();//second oprand
        int d2=st.pop();//first oprand
        int res = 0;
        if(token.equals("+")){
          res=d1+d2;
        }else if(token.equals("-")){
          res=d1-d2;
        }else if(token.equals("*")){
          res=d1*d2;
        }else if(token.equals("/")){
          res=d1/d2;
        }
          st.push(res);
      }else{
        st.push(Integer.parseInt(token));
      }
    }
    return st.peek();
  }
  public static void main(String[] args) {
    String[] tokens={"2","1","+","3","*"};
    System.out.println(RPN(tokens));
  }
}
