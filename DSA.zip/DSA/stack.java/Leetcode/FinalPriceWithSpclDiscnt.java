import java.util.Arrays;
import java.util.Stack;
public class FinalPriceWithSpclDiscnt {
  public static int[] finPrice(int prices[]){
    Stack<Integer> st= new Stack<>();
    int res[]=new int[prices.length];
    for(int i=0;i<prices.length;i++){
      while(!st.isEmpty() && prices[st.peek()]>=prices[i]){
        int idx=st.pop();
        res[idx]=prices[idx]-prices[i];
      }
      st.push(i);
    }
    while(!st.isEmpty()){
      int idx=st.pop(); //  all are less than st.pop
      res[idx]=prices[idx];
    }
    return res;
  }
  public static void main(String[] args) {
    int prices[]={8,4,6,2,3};
    finPrice(prices);
    System.out.println(Arrays.toString(prices));
  }
}
