public class MinAddToMakeParenth {
  public static int minAdd(String s){
          int openPrenth=0;
        int closedPrenth=0;
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(ch=='('){
                closedPrenth++;
            }else if(ch==')' && closedPrenth>0){
                closedPrenth--;
            }else{
                openPrenth++;
            }
        }
        return openPrenth+closedPrenth;
    }
    public static void main(String[] args) {
      String s="())";
      System.out.println(minAdd(s));
    }
  }
  
