import java.util.Stack;
public class MinDeletionMakeStringBalanced {
  public static int Min_del_String(String s){
    int  n=s.length();
    Stack<Character> st =new Stack<>();
    int count =0;
    for(int i=0;i<s.length();i++){
      char ch=s.charAt(i);
      if(!st.isEmpty() && ch=='a' && st.peek()=='b'){
        st.pop();
        count++;
      }else{
        st.push(ch);
      }
    }
    return count ;
  }
  public static void main(String[] args) {
    String s="aababbab";
    System.out.println(Min_del_String(s));
  }
}
