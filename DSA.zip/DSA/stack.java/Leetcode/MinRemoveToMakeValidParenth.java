import java.util.Stack;
public class MinRemoveToMakeValidParenth {
    public static String minRemoveToMakeValid(String s) {
    char ch[]=s.toCharArray();//string convert in character array
    Stack<Integer> st=new Stack<>(); //only index push in st
    for(int i=0;i<ch.length;i++){
        if(ch[i]=='('){
            st.push(i);
        }else if(ch[i]==')'){ 
            if(st.size()==0){//closing parenth ke jab koi pair st me n ho
                 ch[i]='*'; //simply use null krdenge * null ko repersent krega
                }else{
                    st.pop(); //agr aisa n ho to uske pair ko pop krenge
                }
            }
        }
        while(st.size()>0){//jab st me koi parenthesis bache to kisi se pair  nhi hua hoga use v hm st se pop krke null  assign krenge
          ch[st.pop()]='*';
        }
        //create string builder to store all char and pair parenthesis
        StringBuilder sb=new StringBuilder();
        for(char c:ch) //ch ke all char ko c me bhejenge
          if(c!='*'){ //new c me null value assign nhi krna h
          sb.append(c);
          }
          return sb.toString();
    }
    public static void main(String[] args) {
      String s="lee(t(c)o)de)";
      System.out.println(minRemoveToMakeValid(s));
    }
  
}
