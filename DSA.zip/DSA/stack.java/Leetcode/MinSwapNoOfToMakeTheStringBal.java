import java.util.Stack;

public class MinSwapNoOfToMakeTheStringBal {
  public static int minSwap(String s){
    Stack<Character> st =new Stack<>();
    int UnMatchedPar=0;
    for(int i=0;i<s.length();i++){
      char ch=s.charAt(i);
      if(ch=='['){
        st.push(ch);
      }else if(!st.isEmpty()){
        st.pop();
      }else{
        UnMatchedPar++;
      }
    }
    return (UnMatchedPar+1)/2;
  }
  public static void main(String[] args) {
    String s="]]][[[";
    System.out.println(minSwap(s));
  }
  
}
