import java.util.Stack;
public class NextGreaterNodeLinkedList {
  public static class ListNode {
    int data;
    ListNode next;

    // cunstructor
    public ListNode(int val) {
      this.data = val;
      this.next = null;
    }
  }
  public int[] nextLargerNodes(ListNode head) {
  Stack<Integer> st = new Stack<>();
  ListNode temp = head;
  // find the len of linkedlist
  int len=0;while(temp!=null)
  {
    temp = temp.next;
    len++;
  }
  // temp=head;
  // store linkedlist into arr
  int arr[] = new int[len];
  int res[] = new int[len];
  // Step 2: Fill values from linked list into array
  temp=head;for(
  int i = 0;temp!=null;i++)
  {
    arr[i] = temp.val;
    temp = temp.next;
  }
  // Step 3: Monotonic stack to find next greater node
  for(
  int i = 0;i<len;i++)
  {
    while (!st.isEmpty() && arr[st.peek()] < arr[i]) {
      int idx = st.pop();
      res[idx] = arr[i];
    }
    st.push(i);
  }
  return res;
}
}
