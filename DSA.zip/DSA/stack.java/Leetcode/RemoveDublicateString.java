import java.util.Stack;
public class RemoveDublicateString {
   public static String removeDuplicates(String s) {
        Stack<Character> st=new Stack<>();
        for(char ch:s.toCharArray()){
            if(!st.isEmpty() && st.peek()== ch){
                st.pop();
            }else{
                st.push(ch);
            }
          }
        StringBuilder sb=new StringBuilder();
        for(char ch1:st){
            sb.append(ch1);
        }
        return sb.toString();
    }
  
    public static void main(String[] args) {
      String s="abbaca";
      System.out.println(removeDuplicates(s));
    }
  
}
