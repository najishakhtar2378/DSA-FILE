public class RemoveOuterPrenth {
  public static String removeOuterParentheses(String s) {
    StringBuilder sb = new StringBuilder();
    int count = 0;
    for (char ch : s.toCharArray()) { // all are in array
      if (ch == '(') {
        if (count > 0) { // count value is greater than 0 according to ( (
          sb.append(ch);
        }
        count++; // increase count when closing bracet doent found
      } else {
        count--; // closing brackend found count decrease
        if (count > 0) {
          sb.append(ch); // append all open and close bracket
        }
      }

    }
    return sb.toString();
  }
  public static void main(String[] args) {
    String s="(()())(())";
    System.out.println(removeOuterParentheses(s));
  }
  
}
