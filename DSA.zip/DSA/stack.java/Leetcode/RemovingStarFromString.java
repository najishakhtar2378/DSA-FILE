import java.util.Stack;
public class RemovingStarFromString {
    public static  String removeStars(String s) {
        Stack<Character>st=new Stack<>();
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(ch=='*' && !st.isEmpty()){
                st.pop(); //pop top element
            }else if(ch!='*'){
                st.push(ch);
            }
        }
       StringBuilder sb=new StringBuilder();
       for( Character ans:st){
          sb.append(ans);
       }
       return sb.toString();
    }
    public static void main(String[] args) {
      String s="leet**cod*e";
      System.out.println(removeStars(s));
    }
}
