import java.util.Stack;
public class ReorderList {
  public static class ListNode {
    int val;
    ListNode next;

    // cunstructor
    public ListNode(int data) {
      this.val = data;
      this.next = null;
    }
  }
  public void reorderList(ListNode head) {
   if (head == null || head.next == null) 
                  return;
        //  Push all nodes into a stack
        Stack<ListNode> stack = new Stack<>();
        ListNode temp = head; //find length
        int length = 0; 
        while (temp != null) {
            stack.push(temp);
            temp = temp.next;
            length++;
        }
        //  Reorder by taking from stack
        temp = head;
        for (int i = 0; i < length / 2; i++) { //itterate 2 times
            ListNode last = stack.pop(); // node from end
            ListNode nextNode = temp.next;
            temp.next = last; // connect current node to last
            last.next = nextNode; // connect last node to next
            temp = nextNode; // move to next
        }

        //Mark end of list
        temp.next = null;
}
}