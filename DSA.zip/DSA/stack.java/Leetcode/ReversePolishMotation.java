import java.util.Stack;

public class ReversePolishMotation {
  public static int EvalRevPolNota(String tokens[]){
    Stack<Integer>st=new Stack<>();
    String oprator="+-*/";
    //forEach loop
    for(String token:tokens){
      // agar oprator ho tb 
      if(oprator.indexOf(token)!=-1){ // oprator ko show kr rha h iska mtlb mere stack me koi na koi element pada h  agr oprator persent hoga to 0,1,2,3 index ko dega agr nhi hoga tb -1 ko dega 
        int d2=st.pop();
        int d1=st.pop();
        int res=0;
        if(token.equals("+")){
          res=d1+d2;
        }
        else if(token.equals("-")){
          res=d1-d2;
        }
        else if(token.equals("*")){
          res=d1*d2;
        }
        else if(token.equals("/")){
          res=d1/d2;
        }
        st.push(res);
      }else{
        st.push(Integer.parseInt(token));// when no assighn any oprater
      }
      
    }
    return st.peek();
    
  }
  public static void main(String[] args) {
    String tokens[]={"2","1","+","3","*"};
    System.out.println(EvalRevPolNota(tokens));
    
  }
  
}
