import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
public class ReverseSubstringBwEachPairOfparen {
   public static String reverseParentheses(String s) {
        Stack<Character> st=new Stack<>();
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(ch==')'){
                Queue<Character> q=new LinkedList<>(); 
                while(st.peek()!='('){ //all element pop untll '('
                    q.add(st.pop()); //add q
                }
                st.pop(); //opening parenthesis ko pop krenge or phir se stack me dalenge
               while(q.size()>0){
                st.push(q.remove()); //phir se st ke ander push krenge or q se remove krenge
                //ye tb tk hoga jb tk all '(' and ')' na ho jaye
               } 
            }else{
                st.push(ch);//jab tk open parenthe na aa jaye tb tk char or closeP push krenege
            }
        }
        //store substring in ans
        char res[] = new char[st.size()];
        int i= res.length-1; //put i pointer at last index
        while(i>=0){
         res[i]=st.pop(); //store ith index of ans element
         i--;
        }
        return  new String(res);
    }
   public static void main(String[] args) {
    String s="(u(love)i)";
    System.out.println(reverseParentheses(s));
   }
}
