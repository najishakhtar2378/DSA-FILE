public class ValidPrenthesisString {
  public static boolean validprenthesisStr(String s){
  int minLeftP=0;
  int maxleftP=0;
  for(int i=0;i<s.length();i++){
    char ch=s.charAt(i);
    if(ch=='('){
      minLeftP++;
      maxleftP++;
    }else if(ch==')'){
      if(minLeftP>0){
        minLeftP--;
      }
      maxleftP--;
    }else{
      if(minLeftP>0){
        minLeftP--;
      }
      maxleftP++;
    }
    if(maxleftP<0){
      return false;
    }
  }
  return minLeftP==0; //last minleftp ==0 for statble
}
public static void main(String[] args) {
  String s="(*))";
  System.out.println(validprenthesisStr(s));
}
}