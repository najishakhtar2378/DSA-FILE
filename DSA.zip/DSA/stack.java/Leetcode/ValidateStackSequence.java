import java.util.Stack;
public class ValidateStackSequence {
  public static boolean valStSeq(int pushed[],int popped[]){
    Stack<Integer> st=new Stack<>();
    int j = 0; // traverse for popped opration
    for(int val:pushed){
      st.push(val);
      
      while(!st.isEmpty() && st.peek()==popped[j]){
        st.pop();
        j++;
      }
    }
    return st.isEmpty();
  }
  public static void main(String[] args) {
    int pushed[]={1,2,3,4,5};
    int popped[]={4,5,3,2,1};
    System.out.println(valStSeq(pushed, popped));
  }
  
}
