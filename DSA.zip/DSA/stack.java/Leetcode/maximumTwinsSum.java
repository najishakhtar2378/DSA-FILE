import java.util.ArrayList;
import java.util.List;

public static class ListNode {
  int val;
  ListNode next;

  // cunstructor
  public ListNode(int val) {
    this.val = val;
    this.next = null;
  }
}
public class maximumTwinsSum {
  public static int pairSum(ListNode head) {
    List<Integer> ls = new ArrayList<>();
   ListNode curr = head;
    while (curr != null) {
      ls.add(curr.val);
      curr = curr.next;
    }
    int i = 0;
    int j = ls.size() - 1;
    int res = 0;
    while (i < j) {
      res = Math.max(res, ls.get(i) + ls.get(j));
      i++;
      j--;
    }
    return res;
  }
  
}
