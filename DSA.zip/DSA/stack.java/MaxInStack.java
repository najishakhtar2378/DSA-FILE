import java.util.Stack;
public class MaxInStack {
  // Stack<Integer> st=new Stack<>();
  Stack<Integer> maxSt=new Stack<>();
 
    public  void push(int data){
      int max=data;
      if(!maxSt.isEmpty() && max<maxSt.peek()){
        max=maxSt.peek();
      }
      // st.push(data);
      maxSt.push(max);
    }
    // public void pop(){
    //   st.pop();
    //   maxSt.pop();
    // }
    public int  peek(){
      return maxSt.peek();
    }
  public static void main(String[] args) {
    MaxInStack  maxelt = new MaxInStack();
    
    maxelt.push(5);
    maxelt.push(3);
    maxelt.push(4);
    maxelt.push(8);
    maxelt.push(6);
    System.out.println(" max element ="+ maxelt.peek());
  }
}
