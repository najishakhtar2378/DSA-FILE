import java.util.Stack;

public class MinElementInStack {
  Stack<Integer> minSt=new Stack<>();
  public void push(int data){
    int min=data;

    while(!minSt.isEmpty()&& min>minSt.peek()){
       min=minSt.peek();
    }
    minSt.push(min);
  }
  public int peek(){
    return minSt.pop();
  }
public static void main(String[] args) {
  MinElementInStack minElt =new MinElementInStack();
  minElt.push(6);
  minElt.push(7);
  minElt.push(3);
  minElt.push(2);
  minElt.push(9);
  System.out.println("min element in satck "+minElt.peek());
}
}
