import java.util.Scanner;
import java.util.Stack;
public class PlindromeStack {

    public static void main(String[] args) {
        System.out.println("Enter any String");
        Scanner in=new Scanner(System.in);
        String str=in.nextLine();
        Stack<Character> s=new Stack<>();
        for(int i=0;i<str.length();i++){
            s.push(str.charAt(i));
        }
        String reverseStr="";
        while(!s.isEmpty()){
         reverseStr+=s.pop();
        }
        if(str.equals(reverseStr)){
            System.out.println("yes it is palindrome");
        }
        else{
            System.out.println("it is not palindrom");
        }
        
    }
    
}
