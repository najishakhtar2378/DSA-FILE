import java.util.Stack;
public class SortStack {
  public static Stack<Integer> sortStack(Stack<Integer>s){
    if(s.isEmpty() || s.size()==-1){
      return s;
    }
    int top=s.pop();
    sortStack(s);
    insert(top,s);
    return s;
  }
  public static void insert( int element, Stack<Integer> s){
    if(s.isEmpty()|| s.peek()<=element){
      s.push(element);
      return;
    }
    // for small element 1
    int top=s.pop();
    insert(element,s);
    s.push(top);
  }
  public static void printStack(Stack<Integer> s){
    while(!s.isEmpty()){
      System.out.println(s.pop());
    }
  }
  public static void main(String[] args) {
    Stack<Integer> s=new Stack<>();
    s.push(3);
    s.push(4);
    s.push(1);
    s.push(5);
  
      sortStack(s);
      printStack(s);
    }
  }

